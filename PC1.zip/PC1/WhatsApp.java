package PC1;

/**
 *
 * @author User
 */
public class WhatsApp implements CanalNotificacion {
    @Override
    public void enviar(Mensaje mensaje) {
        System.out.println("Enviando por WhatsApp: " + mensaje.getContenido());
    }
}