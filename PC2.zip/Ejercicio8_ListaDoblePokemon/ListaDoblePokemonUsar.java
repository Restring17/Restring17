package Ejercicio8_ListaDoblePokemon;

/**
 * Lista doblemente enlazada de Pokemon con algoritmos de ordenamiento
 * Basada en Laboratorio09_EstacionesTren
 */
public class ListaDoblePokemonUsar implements ListaDoblePokemon {
    private NodoDoblePokemon cabeza;
    private NodoDoblePokemon cola;
    private int tamanio;

    public ListaDoblePokemonUsar() {
        this.cabeza = null;
        this.cola = null;
        this.tamanio = 0;
    }

    @Override
    public void agregarInicio(Pokemon pokemon) {
        NodoDoblePokemon nuevo = new NodoDoblePokemon(pokemon);
        if (cabeza == null) {
            cabeza = cola = nuevo;
        } else {
            nuevo.setSiguiente(cabeza);
            cabeza.setAnterior(nuevo);
            cabeza = nuevo;
        }
        tamanio++;
    }

    @Override
    public void agregarFinal(Pokemon pokemon) {
        NodoDoblePokemon nuevo = new NodoDoblePokemon(pokemon);
        if (cola == null) {
            cabeza = cola = nuevo;
        } else {
            cola.setSiguiente(nuevo);
            nuevo.setAnterior(cola);
            cola = nuevo;
        }
        tamanio++;
    }

    @Override
    public boolean eliminar(String nombre) {
        if (cabeza == null) return false;
        NodoDoblePokemon temp = cabeza;
        while (temp != null) {
            if (temp.getPokemon().getNombre().equals(nombre)) {
                if (temp == cabeza) cabeza = temp.getSiguiente();
                if (temp == cola) cola = temp.getAnterior();
                if (temp.getAnterior() != null) temp.getAnterior().setSiguiente(temp.getSiguiente());
                if (temp.getSiguiente() != null) temp.getSiguiente().setAnterior(temp.getAnterior());
                tamanio--;
                return true;
            }
            temp = temp.getSiguiente();
        }
        return false;
    }

    @Override
    public boolean contiene(String nombre) {
        NodoDoblePokemon temp = cabeza;
        while (temp != null) {
            if (temp.getPokemon().getNombre().equals(nombre)) return true;
            temp = temp.getSiguiente();
        }
        return false;
    }

    @Override
    public void imprimirAdelante() {
        System.out.print("null <- ");
        NodoDoblePokemon temp = cabeza;
        while (temp != null) {
            System.out.print(temp.getPokemon() + " <-> ");
            temp = temp.getSiguiente();
        }
        System.out.println("null");
    }

    @Override
    public void imprimirAtras() {
        System.out.print("null -> ");
        NodoDoblePokemon temp = cola;
        while (temp != null) {
            System.out.print(temp.getPokemon() + " <-> ");
            temp = temp.getAnterior();
        }
        System.out.println("null");
    }

    @Override
    public boolean estaVacia() {
        return cabeza == null;
    }

    @Override
    public int tamanio() {
        return tamanio;
    }

    // ========== ORDENAMIENTO POR PODER ==========
    
    @Override
    public void OrdenarBubbleSortPorPoder() {
        if (cabeza == null || cabeza.getSiguiente() == null) return;
        boolean huboIntercambio;
        do {
            huboIntercambio = false;
            NodoDoblePokemon temp = cabeza;
            while (temp.getSiguiente() != null) {
                if (temp.getPokemon().getPoder() > temp.getSiguiente().getPokemon().getPoder()) {
                    Pokemon pokemonTemp = temp.getPokemon();
                    temp.setPokemon(temp.getSiguiente().getPokemon());
                    temp.getSiguiente().setPokemon(pokemonTemp);
                    huboIntercambio = true;
                }
                temp = temp.getSiguiente();
            }
        } while (huboIntercambio);
    }

    @Override
    public void OrdenarSelectionSortPorPoder() {
        if (cabeza == null || cabeza.getSiguiente() == null) return;
        NodoDoblePokemon i = cabeza;
        while (i != null) {
            NodoDoblePokemon minNodo = i;
            NodoDoblePokemon j = i.getSiguiente();
            while (j != null) {
                if (j.getPokemon().getPoder() < minNodo.getPokemon().getPoder()) minNodo = j;
                j = j.getSiguiente();
            }
            if (minNodo != i) {
                Pokemon temp = i.getPokemon();
                i.setPokemon(minNodo.getPokemon());
                minNodo.setPokemon(temp);
            }
            i = i.getSiguiente();
        }
    }

    @Override
    public void OrdenarInsertionSortPorPoder() {
        if (cabeza == null || cabeza.getSiguiente() == null) return;
        NodoDoblePokemon ordenada = null;
        NodoDoblePokemon current = cabeza;
        while (current != null) {
            NodoDoblePokemon siguiente = current.getSiguiente();
            current.setAnterior(null);
            current.setSiguiente(null);
            ordenada = insertarOrdenadoPoder(ordenada, current);
            current = siguiente;
        }
        cabeza = ordenada;
        cola = cabeza;
        if (cola != null) while (cola.getSiguiente() != null) cola = cola.getSiguiente();
    }

    private NodoDoblePokemon insertarOrdenadoPoder(NodoDoblePokemon ordenada, NodoDoblePokemon nuevo) {
        if (ordenada == null || ordenada.getPokemon().getPoder() >= nuevo.getPokemon().getPoder()) {
            nuevo.setSiguiente(ordenada);
            if (ordenada != null) ordenada.setAnterior(nuevo);
            return nuevo;
        }
        NodoDoblePokemon temp = ordenada;
        while (temp.getSiguiente() != null && temp.getSiguiente().getPokemon().getPoder() < nuevo.getPokemon().getPoder()) {
            temp = temp.getSiguiente();
        }
        nuevo.setSiguiente(temp.getSiguiente());
        if (temp.getSiguiente() != null) temp.getSiguiente().setAnterior(nuevo);
        temp.setSiguiente(nuevo);
        nuevo.setAnterior(temp);
        return ordenada;
    }

    @Override
    public void OrdenarMergeSortPorPoder() {
        cabeza = mergeSortPoder(cabeza);
        cola = cabeza;
        if (cola != null) while (cola.getSiguiente() != null) cola = cola.getSiguiente();
    }

    private NodoDoblePokemon mergeSortPoder(NodoDoblePokemon inicio) {
        if (inicio == null || inicio.getSiguiente() == null) return inicio;
        NodoDoblePokemon medio = obtenerMitad(inicio);
        NodoDoblePokemon segundaMitad = medio.getSiguiente();
        medio.setSiguiente(null);
        if (segundaMitad != null) segundaMitad.setAnterior(null);
        return fusionarPoder(mergeSortPoder(inicio), mergeSortPoder(segundaMitad));
    }

    private NodoDoblePokemon fusionarPoder(NodoDoblePokemon l1, NodoDoblePokemon l2) {
        if (l1 == null) return l2;
        if (l2 == null) return l1;
        if (l1.getPokemon().getPoder() <= l2.getPokemon().getPoder()) {
            l1.setSiguiente(fusionarPoder(l1.getSiguiente(), l2));
            if (l1.getSiguiente() != null) l1.getSiguiente().setAnterior(l1);
            l1.setAnterior(null);
            return l1;
        } else {
            l2.setSiguiente(fusionarPoder(l1, l2.getSiguiente()));
            if (l2.getSiguiente() != null) l2.getSiguiente().setAnterior(l2);
            l2.setAnterior(null);
            return l2;
        }
    }

    @Override
    public void OrdenarQuickSortPorPoder() {
        cabeza = quickSortPoder(cabeza);
        cola = cabeza;
        if (cola != null) while (cola.getSiguiente() != null) cola = cola.getSiguiente();
    }

    private NodoDoblePokemon quickSortPoder(NodoDoblePokemon inicio) {
        if (inicio == null || inicio.getSiguiente() == null) return inicio;
        NodoDoblePokemon pivote = inicio;
        NodoDoblePokemon menores = null, mayores = null, temp = inicio.getSiguiente();
        while (temp != null) {
            NodoDoblePokemon siguiente = temp.getSiguiente();
            temp.setSiguiente(null);
            temp.setAnterior(null);
            if (temp.getPokemon().getPoder() < pivote.getPokemon().getPoder()) {
                temp.setSiguiente(menores);
                if (menores != null) menores.setAnterior(temp);
                menores = temp;
            } else {
                temp.setSiguiente(mayores);
                if (mayores != null) mayores.setAnterior(temp);
                mayores = temp;
            }
            temp = siguiente;
        }
        menores = quickSortPoder(menores);
        mayores = quickSortPoder(mayores);
        if (menores == null) {
            pivote.setSiguiente(mayores);
            if (mayores != null) mayores.setAnterior(pivote);
            return pivote;
        }
        NodoDoblePokemon fin = menores;
        while (fin.getSiguiente() != null) fin = fin.getSiguiente();
        fin.setSiguiente(pivote);
        pivote.setAnterior(fin);
        pivote.setSiguiente(mayores);
        if (mayores != null) mayores.setAnterior(pivote);
        return menores;
    }

    // ========== ORDENAMIENTO POR NOMBRE ==========
    
    @Override
    public void OrdenarBubbleSortPorNombre() {
        if (cabeza == null || cabeza.getSiguiente() == null) return;
        boolean huboIntercambio;
        do {
            huboIntercambio = false;
            NodoDoblePokemon temp = cabeza;
            while (temp.getSiguiente() != null) {
                if (temp.getPokemon().getNombre().compareTo(temp.getSiguiente().getPokemon().getNombre()) > 0) {
                    Pokemon pokemonTemp = temp.getPokemon();
                    temp.setPokemon(temp.getSiguiente().getPokemon());
                    temp.getSiguiente().setPokemon(pokemonTemp);
                    huboIntercambio = true;
                }
                temp = temp.getSiguiente();
            }
        } while (huboIntercambio);
    }

    @Override
    public void OrdenarSelectionSortPorNombre() {
        if (cabeza == null || cabeza.getSiguiente() == null) return;
        NodoDoblePokemon i = cabeza;
        while (i != null) {
            NodoDoblePokemon minNodo = i;
            NodoDoblePokemon j = i.getSiguiente();
            while (j != null) {
                if (j.getPokemon().getNombre().compareTo(minNodo.getPokemon().getNombre()) < 0) minNodo = j;
                j = j.getSiguiente();
            }
            if (minNodo != i) {
                Pokemon temp = i.getPokemon();
                i.setPokemon(minNodo.getPokemon());
                minNodo.setPokemon(temp);
            }
            i = i.getSiguiente();
        }
    }

    @Override
    public void OrdenarInsertionSortPorNombre() {
        if (cabeza == null || cabeza.getSiguiente() == null) return;
        NodoDoblePokemon ordenada = null;
        NodoDoblePokemon current = cabeza;
        while (current != null) {
            NodoDoblePokemon siguiente = current.getSiguiente();
            current.setAnterior(null);
            current.setSiguiente(null);
            ordenada = insertarOrdenadoNombre(ordenada, current);
            current = siguiente;
        }
        cabeza = ordenada;
        cola = cabeza;
        if (cola != null) while (cola.getSiguiente() != null) cola = cola.getSiguiente();
    }

    private NodoDoblePokemon insertarOrdenadoNombre(NodoDoblePokemon ordenada, NodoDoblePokemon nuevo) {
        if (ordenada == null || ordenada.getPokemon().getNombre().compareTo(nuevo.getPokemon().getNombre()) >= 0) {
            nuevo.setSiguiente(ordenada);
            if (ordenada != null) ordenada.setAnterior(nuevo);
            return nuevo;
        }
        NodoDoblePokemon temp = ordenada;
        while (temp.getSiguiente() != null && temp.getSiguiente().getPokemon().getNombre().compareTo(nuevo.getPokemon().getNombre()) < 0) {
            temp = temp.getSiguiente();
        }
        nuevo.setSiguiente(temp.getSiguiente());
        if (temp.getSiguiente() != null) temp.getSiguiente().setAnterior(nuevo);
        temp.setSiguiente(nuevo);
        nuevo.setAnterior(temp);
        return ordenada;
    }

    @Override
    public void OrdenarMergeSortPorNombre() {
        cabeza = mergeSortNombre(cabeza);
        cola = cabeza;
        if (cola != null) while (cola.getSiguiente() != null) cola = cola.getSiguiente();
    }

    private NodoDoblePokemon mergeSortNombre(NodoDoblePokemon inicio) {
        if (inicio == null || inicio.getSiguiente() == null) return inicio;
        NodoDoblePokemon medio = obtenerMitad(inicio);
        NodoDoblePokemon segundaMitad = medio.getSiguiente();
        medio.setSiguiente(null);
        if (segundaMitad != null) segundaMitad.setAnterior(null);
        return fusionarNombre(mergeSortNombre(inicio), mergeSortNombre(segundaMitad));
    }

    private NodoDoblePokemon fusionarNombre(NodoDoblePokemon l1, NodoDoblePokemon l2) {
        if (l1 == null) return l2;
        if (l2 == null) return l1;
        if (l1.getPokemon().getNombre().compareTo(l2.getPokemon().getNombre()) <= 0) {
            l1.setSiguiente(fusionarNombre(l1.getSiguiente(), l2));
            if (l1.getSiguiente() != null) l1.getSiguiente().setAnterior(l1);
            l1.setAnterior(null);
            return l1;
        } else {
            l2.setSiguiente(fusionarNombre(l1, l2.getSiguiente()));
            if (l2.getSiguiente() != null) l2.getSiguiente().setAnterior(l2);
            l2.setAnterior(null);
            return l2;
        }
    }

    @Override
    public void OrdenarQuickSortPorNombre() {
        cabeza = quickSortNombre(cabeza);
        cola = cabeza;
        if (cola != null) while (cola.getSiguiente() != null) cola = cola.getSiguiente();
    }

    private NodoDoblePokemon quickSortNombre(NodoDoblePokemon inicio) {
        if (inicio == null || inicio.getSiguiente() == null) return inicio;
        NodoDoblePokemon pivote = inicio;
        NodoDoblePokemon menores = null, mayores = null, temp = inicio.getSiguiente();
        while (temp != null) {
            NodoDoblePokemon siguiente = temp.getSiguiente();
            temp.setSiguiente(null);
            temp.setAnterior(null);
            if (temp.getPokemon().getNombre().compareTo(pivote.getPokemon().getNombre()) < 0) {
                temp.setSiguiente(menores);
                if (menores != null) menores.setAnterior(temp);
                menores = temp;
            } else {
                temp.setSiguiente(mayores);
                if (mayores != null) mayores.setAnterior(temp);
                mayores = temp;
            }
            temp = siguiente;
        }
        menores = quickSortNombre(menores);
        mayores = quickSortNombre(mayores);
        if (menores == null) {
            pivote.setSiguiente(mayores);
            if (mayores != null) mayores.setAnterior(pivote);
            return pivote;
        }
        NodoDoblePokemon fin = menores;
        while (fin.getSiguiente() != null) fin = fin.getSiguiente();
        fin.setSiguiente(pivote);
        pivote.setAnterior(fin);
        pivote.setSiguiente(mayores);
        if (mayores != null) mayores.setAnterior(pivote);
        return menores;
    }

    // ========== MÉTODOS AUXILIARES ==========
    
    private NodoDoblePokemon obtenerMitad(NodoDoblePokemon inicio) {
        if (inicio == null) return null;
        NodoDoblePokemon lento = inicio, rapido = inicio;
        while (rapido.getSiguiente() != null && rapido.getSiguiente().getSiguiente() != null) {
            lento = lento.getSiguiente();
            rapido = rapido.getSiguiente().getSiguiente();
        }
        return lento;
    }
}
