package Ejercicio1;

/**
 *
 * @author User
 */
public class Nodo {
    Nodo siguiente;
    int valor;

    public Nodo(int valor) {
        this.valor = valor;
        this.siguiente=null;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
}
