package Ejercicio9_ListaDobleString;

public class NodoDobleString {
    private String valor;
    private NodoDobleString anterior;
    private NodoDobleString siguiente;

    public NodoDobleString(String valor) {
        this.valor = valor;
        this.anterior = null;
        this.siguiente = null;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public NodoDobleString getAnterior() {
        return anterior;
    }

    public void setAnterior(NodoDobleString anterior) {
        this.anterior = anterior;
    }

    public NodoDobleString getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoDobleString siguiente) {
        this.siguiente = siguiente;
    }
}
