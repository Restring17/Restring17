package PC2_Preparacion.controlador;

import PC2_Preparacion.modelo.*;

/**
 * CONTROLADOR CON SOLUCIONES - LISTA SIMPLE
 * 
 * Este archivo contiene las SOLUCIONES COMPLETAS de las 9 preguntas.
 * Úsalo como REFERENCIA si te atascas, pero intenta resolver primero por tu cuenta.
 */
public class ListaSimpleController_SOLUCIONES {
    private NodoSimple cabeza;
    private int tamano;

    public ListaSimpleController_SOLUCIONES() {
        this.cabeza = null;
        this.tamano = 0;
    }

    public void agregar(Estudiante estudiante) {
        NodoSimple nuevo = new NodoSimple(estudiante);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            NodoSimple actual = cabeza;
            while (actual.getSiguiente() != null) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(nuevo);
        }
        tamano++;
    }

    public Estudiante[] toArray() {
        Estudiante[] array = new Estudiante[tamano];
        NodoSimple actual = cabeza;
        int i = 0;
        while (actual != null) {
            array[i++] = actual.getDato();
            actual = actual.getSiguiente();
        }
        return array;
    }

    private void fromArray(Estudiante[] array) {
        cabeza = null;
        tamano = 0;
        for (Estudiante e : array) {
            agregar(e);
        }
    }

    // ==================== PREGUNTA 1A: BUBBLE SORT ====================
    
    /**
     * SOLUCIÓN: Ordenar por promedio (descendente) con Bubble Sort
     */
    public void ordenarPorPromedioBubbleSort() {
        if (tamano <= 1) return;
        
        Estudiante[] array = toArray();
        
        for (int i = 0; i < array.length - 1; i++) {
            for (int j = 0; j < array.length - 1 - i; j++) {
                // Descendente: mayor primero
                if (array[j].getPromedio() < array[j + 1].getPromedio()) {
                    Estudiante temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }
        
        fromArray(array);
    }

    // ==================== PREGUNTA 1B: QUICK SORT ====================
    
    /**
     * SOLUCIÓN: Ordenar por nombre (alfabético) con Quick Sort
     */
    public void ordenarPorNombreQuickSort() {
        if (tamano <= 1) return;
        
        Estudiante[] array = toArray();
        quickSortRecursivo(array, 0, array.length - 1);
        fromArray(array);
    }

    private void quickSortRecursivo(Estudiante[] array, int inicio, int fin) {
        if (inicio < fin) {
            int pivote = particion(array, inicio, fin);
            quickSortRecursivo(array, inicio, pivote - 1);
            quickSortRecursivo(array, pivote + 1, fin);
        }
    }

    private int particion(Estudiante[] array, int inicio, int fin) {
        Estudiante pivote = array[fin];
        int i = inicio - 1;
        
        for (int j = inicio; j < fin; j++) {
            // Orden alfabético ascendente
            if (array[j].getNombre().compareToIgnoreCase(pivote.getNombre()) <= 0) {
                i++;
                Estudiante temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
        
        Estudiante temp = array[i + 1];
        array[i + 1] = array[fin];
        array[fin] = temp;
        
        return i + 1;
    }

    // ==================== PREGUNTA 1C: MERGE SORT ====================
    
    /**
     * SOLUCIÓN: Ordenar por código con Merge Sort
     */
    public void ordenarPorCodigoMergeSort() {
        if (tamano <= 1) return;
        
        Estudiante[] array = toArray();
        mergeSortRecursivo(array, 0, array.length - 1);
        fromArray(array);
    }

    private void mergeSortRecursivo(Estudiante[] array, int inicio, int fin) {
        if (inicio < fin) {
            int medio = (inicio + fin) / 2;
            mergeSortRecursivo(array, inicio, medio);
            mergeSortRecursivo(array, medio + 1, fin);
            merge(array, inicio, medio, fin);
        }
    }

    private void merge(Estudiante[] array, int inicio, int medio, int fin) {
        int n1 = medio - inicio + 1;
        int n2 = fin - medio;
        
        Estudiante[] izq = new Estudiante[n1];
        Estudiante[] der = new Estudiante[n2];
        
        for (int i = 0; i < n1; i++) {
            izq[i] = array[inicio + i];
        }
        for (int j = 0; j < n2; j++) {
            der[j] = array[medio + 1 + j];
        }
        
        int i = 0, j = 0, k = inicio;
        
        while (i < n1 && j < n2) {
            if (izq[i].getCodigo().compareToIgnoreCase(der[j].getCodigo()) <= 0) {
                array[k++] = izq[i++];
            } else {
                array[k++] = der[j++];
            }
        }
        
        while (i < n1) array[k++] = izq[i++];
        while (j < n2) array[k++] = der[j++];
    }

    // ==================== PREGUNTA 2A: BÚSQUEDA SECUENCIAL ====================
    
    /**
     * SOLUCIÓN: Búsqueda secuencial por nombre (parcial)
     * ⚠️ LECCIÓN DEL PC1: NO retornar dentro del loop
     */
    public Estudiante[] buscarPorNombre(String nombreBuscado) {
        // Primera pasada: contar coincidencias
        int contador = 0;
        NodoSimple actual = cabeza;
        
        while (actual != null) {
            if (actual.getDato().getNombre().toLowerCase()
                      .contains(nombreBuscado.toLowerCase())) {
                contador++;
            }
            actual = actual.getSiguiente();
        }
        
        // Segunda pasada: llenar array
        Estudiante[] resultado = new Estudiante[contador];
        actual = cabeza;
        int indice = 0;
        
        while (actual != null) {
            if (actual.getDato().getNombre().toLowerCase()
                      .contains(nombreBuscado.toLowerCase())) {
                resultado[indice++] = actual.getDato();
            }
            actual = actual.getSiguiente();
        }
        
        return resultado;
    }

    // ==================== PREGUNTA 2B: BÚSQUEDA POR PROMEDIO MÍNIMO ====================
    
    /**
     * SOLUCIÓN: Búsqueda secuencial por promedio mínimo
     */
    public Estudiante[] buscarPorPromedioMinimo(double promedioMinimo) {
        // Primera pasada: contar
        int contador = 0;
        NodoSimple actual = cabeza;
        
        while (actual != null) {
            if (actual.getDato().getPromedio() >= promedioMinimo) {
                contador++;
            }
            actual = actual.getSiguiente();
        }
        
        // Segunda pasada: llenar array
        Estudiante[] resultado = new Estudiante[contador];
        actual = cabeza;
        int indice = 0;
        
        while (actual != null) {
            if (actual.getDato().getPromedio() >= promedioMinimo) {
                resultado[indice++] = actual.getDato();
            }
            actual = actual.getSiguiente();
        }
        
        return resultado;
    }
    
    // ==================== PREGUNTA 2C: BÚSQUEDA POR PREFIJO ====================
    
    /**
     * SOLUCIÓN: Búsqueda secuencial por prefijo de código
     */
    public Estudiante[] buscarPorCodigoPrefijo(String prefijo) {
        // Primera pasada: contar
        int contador = 0;
        NodoSimple actual = cabeza;
        
        while (actual != null) {
            if (actual.getDato().getCodigo().startsWith(prefijo)) {
                contador++;
            }
            actual = actual.getSiguiente();
        }
        
        // Segunda pasada: llenar array
        Estudiante[] resultado = new Estudiante[contador];
        actual = cabeza;
        int indice = 0;
        
        while (actual != null) {
            if (actual.getDato().getCodigo().startsWith(prefijo)) {
                resultado[indice++] = actual.getDato();
            }
            actual = actual.getSiguiente();
        }
        
        return resultado;
    }

    // ==================== PREGUNTA 3A: ELIMINAR ====================
    
    /**
     * SOLUCIÓN: Eliminar estudiantes con promedio < X
     */
    public int eliminarPorPromedioMenorA(double promedioMinimo) {
        int eliminados = 0;
        
        // Eliminar al inicio mientras sea necesario
        while (cabeza != null && cabeza.getDato().getPromedio() < promedioMinimo) {
            cabeza = cabeza.getSiguiente();
            eliminados++;
            tamano--;
        }
        
        if (cabeza == null) return eliminados;
        
        // Eliminar en el resto de la lista
        NodoSimple actual = cabeza;
        while (actual.getSiguiente() != null) {
            if (actual.getSiguiente().getDato().getPromedio() < promedioMinimo) {
                actual.setSiguiente(actual.getSiguiente().getSiguiente());
                eliminados++;
                tamano--;
            } else {
                actual = actual.getSiguiente();
            }
        }
        
        return eliminados;
    }

    // ==================== PREGUNTA 3B: CONTAR ====================
    
    /**
     * SOLUCIÓN: Contar estudiantes por ciclo
     */
    public int contarPorCiclo(int ciclo) {
        int contador = 0;
        NodoSimple actual = cabeza;
        
        while (actual != null) {
            if (actual.getDato().getCiclo() == ciclo) {
                contador++;
            }
            actual = actual.getSiguiente();
        }
        
        return contador;
    }

    // ==================== PREGUNTA 3C: INSERTAR ORDENADO ====================
    
    /**
     * SOLUCIÓN: Insertar manteniendo orden (por promedio descendente)
     */
    public void insertarOrdenado(Estudiante estudiante) {
        NodoSimple nuevo = new NodoSimple(estudiante);
        
        // Lista vacía o insertar al inicio
        if (cabeza == null || estudiante.getPromedio() > cabeza.getDato().getPromedio()) {
            nuevo.setSiguiente(cabeza);
            cabeza = nuevo;
            tamano++;
            return;
        }
        
        // Buscar posición correcta
        NodoSimple actual = cabeza;
        while (actual.getSiguiente() != null && 
               actual.getSiguiente().getDato().getPromedio() >= estudiante.getPromedio()) {
            actual = actual.getSiguiente();
        }
        
        // Insertar
        nuevo.setSiguiente(actual.getSiguiente());
        actual.setSiguiente(nuevo);
        tamano++;
    }

    // ==================== PREGUNTA 3D: TOP N ====================
    
    /**
     * SOLUCIÓN: Obtener los N mejores estudiantes
     */
    public Estudiante[] obtenerTopN(int n) {
        // Ordenar por promedio descendente
        ordenarPorPromedioBubbleSort();
        
        // Tomar los primeros N
        int cantidad = Math.min(n, tamano);
        Estudiante[] top = new Estudiante[cantidad];
        
        NodoSimple actual = cabeza;
        for (int i = 0; i < cantidad; i++) {
            top[i] = actual.getDato();
            actual = actual.getSiguiente();
        }
        
        return top;
    }

    /**
     * SOLUCIÓN: Obtener estudiantes en rango de promedio
     */
    public Estudiante[] obtenerEnRangoPromedio(double promedioMin, double promedioMax) {
        // Primera pasada: contar
        int contador = 0;
        NodoSimple actual = cabeza;
        
        while (actual != null) {
            double promedio = actual.getDato().getPromedio();
            if (promedio >= promedioMin && promedio <= promedioMax) {
                contador++;
            }
            actual = actual.getSiguiente();
        }
        
        // Segunda pasada: llenar array
        Estudiante[] resultado = new Estudiante[contador];
        actual = cabeza;
        int indice = 0;
        
        while (actual != null) {
            double promedio = actual.getDato().getPromedio();
            if (promedio >= promedioMin && promedio <= promedioMax) {
                resultado[indice++] = actual.getDato();
            }
            actual = actual.getSiguiente();
        }
        
        return resultado;
    }

    // Getters
    public int getTamano() { return tamano; }
    public NodoSimple getCabeza() { return cabeza; }
}
