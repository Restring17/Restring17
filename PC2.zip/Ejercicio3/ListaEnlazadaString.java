package Ejercicio3;

/**
 *
 * @author User
 */
public interface ListaEnlazadaString {
    void agregarInicio(String valor);
    void agregarFinal(String valor);
    boolean eliminar(String valor);
    boolean contiene(String valor);
    boolean contieneOrdenado(String valor);
    void imprimir();
    
    //Ordenamiento
    void OrdenarBubbleSort();
    void OrdenarSelectionSort();
    void OrdenarMergeSort();
    void OrdenarQuickSort();
    void OrdenarInsertionSort();
}
