package modelo;

import enums.CondicionContrato;
import enums.Especialidad;
import factory.Contrato;
import facade.CalculadoraSalarial;

public class Arquitecto {
    private String codigo;
    private String nombres;
    private CondicionContrato condicionContrato;
    private Especialidad especialidad;
    private int supervisionObras;
    private int supervisionVias;
    private int numeroObrasSinganadas;
    private boolean usarAFP;
    
    private CalculadoraSalarial calculadoraSalarial;
    
    private Arquitecto() {
        this.calculadoraSalarial = new CalculadoraSalarial();
    }
    
    public String getCodigo() {
        return codigo;
    }
    
    public String getNombres() {
        return nombres;
    }
    
    public CondicionContrato getCondicionContrato() {
        return condicionContrato;
    }
    
    public Especialidad getEspecialidad() {
        return especialidad;
    }
    
    public int getSupervisionObras() {
        return supervisionObras;
    }
    
    public int getSupervisionVias() {
        return supervisionVias;
    }
    
    public int getNumeroObrasSinganadas() {
        return numeroObrasSinganadas;
    }
    
    public double calcularSueldoBase() {
        return calculadoraSalarial.calcularSueldoBase(condicionContrato, supervisionObras, supervisionVias);
    }
    
    public double calcularBonificacion() {
        double sueldoBase = calcularSueldoBase();
        return calculadoraSalarial.calcularBonificacion(sueldoBase, especialidad);
    }
    
    public double calcularDescuento() {
        double sueldoBase = calcularSueldoBase();
        return usarAFP ? calculadoraSalarial.calcularDescuentoAFP(sueldoBase) 
                       : calculadoraSalarial.calcularDescuentoSNP(sueldoBase);
    }
    
    public double calcularMovilidad() {
        return calculadoraSalarial.calcularMovilidad(numeroObrasSinganadas);
    }
    
    public double calcularSueldoNeto() {
        return calculadoraSalarial.calcularSueldoNeto(condicionContrato, supervisionObras, 
                                                      supervisionVias, especialidad, 
                                                      numeroObrasSinganadas, usarAFP);
    }
    
    public void mostrarInformacion() {
        System.out.println("\n========================================");
        System.out.println("INFORMACIÓN DEL ARQUITECTO");
        System.out.println("========================================");
        System.out.println("Código: " + codigo);
        System.out.println("Nombres: " + nombres);
        System.out.println("Condición: " + condicionContrato);
        System.out.println("Especialidad: " + especialidad);
        System.out.println("Supervisión Obras: " + supervisionObras);
        System.out.println("Supervisión Vías: " + supervisionVias);
        System.out.println("Número Obras Asignadas: " + numeroObrasSinganadas);
        System.out.println("Tipo Descuento: " + (usarAFP ? "AFP (15%)" : "SNP (8%)"));
        System.out.println("\n--- CÁLCULOS ---");
        System.out.println("Sueldo Base: S/ " + String.format("%.2f", calcularSueldoBase()));
        System.out.println("Bonificación: S/ " + String.format("%.2f", calcularBonificacion()));
        System.out.println("Descuento: S/ " + String.format("%.2f", calcularDescuento()));
        System.out.println("Movilidad: S/ " + String.format("%.2f", calcularMovilidad()));
        System.out.println("----------------------------------------");
        System.out.println("SUELDO NETO: S/ " + String.format("%.2f", calcularSueldoNeto()));
        System.out.println("========================================\n");
    }
    
    public static class Builder {
        private Arquitecto arquitecto;
        
        public Builder() {
            arquitecto = new Arquitecto();
        }
        
        public Builder conCodigo(String codigo) {
            arquitecto.codigo = codigo;
            return this;
        }
        
        public Builder conNombres(String nombres) {
            arquitecto.nombres = nombres;
            return this;
        }
        
        public Builder conContrato(Contrato contrato) {
            arquitecto.condicionContrato = contrato.obtenerCondicion();
            arquitecto.supervisionObras = contrato.getSupervisionObras();
            arquitecto.supervisionVias = contrato.getSupervisionVias();
            return this;
        }
        
        public Builder conEspecialidad(Especialidad especialidad) {
            arquitecto.especialidad = especialidad;
            return this;
        }
        
        public Builder conNumeroObras(int numeroObras) {
            arquitecto.numeroObrasSinganadas = numeroObras;
            return this;
        }
        
        public Builder conDescuentoAFP() {
            arquitecto.usarAFP = true;
            return this;
        }
        
        public Builder conDescuentoSNP() {
            arquitecto.usarAFP = false;
            return this;
        }
        
        public Arquitecto build() {
            // Validaciones
            if (arquitecto.codigo == null || arquitecto.nombres == null) {
                throw new IllegalStateException("El código y nombres son obligatorios");
            }
            if (arquitecto.condicionContrato == null) {
                throw new IllegalStateException("Debe configurar un contrato");
            }
            if (arquitecto.especialidad == null) {
                throw new IllegalStateException("Debe configurar una especialidad");
            }
            
            return arquitecto;
        }
    }
}
