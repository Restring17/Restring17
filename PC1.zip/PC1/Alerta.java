package PC1;

/**
 *
 * @author User
 */
public class Alerta extends Mensaje {
    public Alerta(String contenido) {
        super(contenido, "Alerta");
    }
}
