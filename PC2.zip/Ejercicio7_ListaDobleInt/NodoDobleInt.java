package Ejercicio7_ListaDobleInt;

public class NodoDobleInt {
    private int valor;
    private NodoDobleInt anterior;
    private NodoDobleInt siguiente;

    public NodoDobleInt(int valor) {
        this.valor = valor;
        this.anterior = null;
        this.siguiente = null;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public NodoDobleInt getAnterior() {
        return anterior;
    }

    public void setAnterior(NodoDobleInt anterior) {
        this.anterior = anterior;
    }

    public NodoDobleInt getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoDobleInt siguiente) {
        this.siguiente = siguiente;
    }
}
