package PC1;

/**
 *
 * @author User
 */
public class SMS implements CanalNotificacion {
    @Override
    public void enviar(Mensaje mensaje) {
        System.out.println("Enviando por SMS: " + mensaje.getContenido());
    }
}