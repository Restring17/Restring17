package Ejercicio4_ListaCircularInt;

/**
 * Interfaz para lista circular de enteros
 * @author User
 */
public interface ListaCircularInt {
    void agregar(int valor);
    void agregarInicio(int valor);
    boolean eliminar(int valor);
    boolean contiene(int valor);
    void imprimir();
    void imprimirCompleta(); // dar una vuelta completa
    void avanzar(); // mover al siguiente nodo
    int obtenerActual();
    boolean estaVacia();
    int tamanio();
    
    // Ordenamiento
    void OrdenarBubbleSort();
    void OrdenarSelectionSort();
    void OrdenarMergeSort();
    void OrdenarQuickSort();
    void OrdenarInsertionSort();
}
