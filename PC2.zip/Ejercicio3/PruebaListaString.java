package Ejercicio3;

/**
 * Clase de prueba para la lista enlazada de String
 * @author User
 */
public class PruebaListaString {
    public static void main(String[] args) {
        ListaEnlazadaStringUsar lista = new ListaEnlazadaStringUsar();
        
        // Agregar Strings
        System.out.println("=== AGREGANDO STRINGS ===");
        lista.agregarFinal("Manzana");
        lista.agregarFinal("Banana");
        lista.agregarFinal("Cereza");
        lista.agregarFinal("Durazno");
        lista.agregarFinal("Fresa");
        lista.agregarInicio("Arándano");
        
        System.out.println("Lista original:");
        lista.imprimir();
        
        // Probar diferentes algoritmos de ordenamiento
        System.out.println("\n=== BUBBLE SORT ===");
        ListaEnlazadaStringUsar listaBubble = new ListaEnlazadaStringUsar();
        agregarFrutas(listaBubble);
        listaBubble.OrdenarBubbleSort();
        listaBubble.imprimir();
        
        System.out.println("\n=== SELECTION SORT ===");
        ListaEnlazadaStringUsar listaSelection = new ListaEnlazadaStringUsar();
        agregarFrutas(listaSelection);
        listaSelection.OrdenarSelectionSort();
        listaSelection.imprimir();
        
        System.out.println("\n=== MERGE SORT ===");
        ListaEnlazadaStringUsar listaMerge = new ListaEnlazadaStringUsar();
        agregarFrutas(listaMerge);
        listaMerge.OrdenarMergeSort();
        listaMerge.imprimir();
        
        System.out.println("\n=== QUICK SORT ===");
        ListaEnlazadaStringUsar listaQuick = new ListaEnlazadaStringUsar();
        agregarFrutas(listaQuick);
        listaQuick.OrdenarQuickSort();
        listaQuick.imprimir();
        
        System.out.println("\n=== INSERTION SORT ===");
        ListaEnlazadaStringUsar listaInsertion = new ListaEnlazadaStringUsar();
        agregarFrutas(listaInsertion);
        listaInsertion.OrdenarInsertionSort();
        listaInsertion.imprimir();
        
        // Operaciones de búsqueda
        System.out.println("\n=== BÚSQUEDA ===");
        System.out.println("¿Contiene 'Manzana'? " + lista.contiene("Manzana"));
        System.out.println("¿Contiene 'Uva'? " + lista.contiene("Uva"));
        
        // Búsqueda en lista ordenada
        ListaEnlazadaStringUsar listaOrdenada = new ListaEnlazadaStringUsar();
        agregarFrutas(listaOrdenada);
        listaOrdenada.OrdenarBubbleSort();
        System.out.println("\nLista ordenada:");
        listaOrdenada.imprimir();
        System.out.println("¿Contiene 'Cereza' (búsqueda ordenada)? " + listaOrdenada.contieneOrdenado("Cereza"));
        System.out.println("¿Contiene 'Kiwi' (búsqueda ordenada)? " + listaOrdenada.contieneOrdenado("Kiwi"));
        
        // Eliminar
        System.out.println("\n=== ELIMINACIÓN ===");
        System.out.println("Eliminando 'Banana': " + lista.eliminar("Banana"));
        lista.imprimir();
        System.out.println("Eliminando 'Uva': " + lista.eliminar("Uva"));
        lista.imprimir();
    }
    
    // Método auxiliar para agregar las mismas frutas a diferentes listas
    private static void agregarFrutas(ListaEnlazadaStringUsar lista) {
        lista.agregarInicio("Arándano");
        lista.agregarFinal("Manzana");
        lista.agregarFinal("Banana");
        lista.agregarFinal("Cereza");
        lista.agregarFinal("Durazno");
        lista.agregarFinal("Fresa");
    }
}
