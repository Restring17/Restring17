package PC2_Preparacion.controlador;

import PC2_Preparacion.modelo.*;

/**
 * ✅ SOLUCIONES COMPLETAS - LISTA CIRCULAR DE PRODUCTOS
 * 
 * Este archivo contiene las 9 preguntas resueltas para listas circulares.
 * Úsalo como guía si te atascas, pero intenta resolver primero en ListaCircularController.java
 */
public class ListaCircularController_SOLUCIONES {
    private NodoCircular cabeza;
    private NodoCircular actual;
    private int tamano;

    public ListaCircularController_SOLUCIONES() {
        this.cabeza = null;
        this.actual = null;
        this.tamano = 0;
    }

    // ==================== OPERACIONES BÁSICAS ====================
    
    public void agregar(Producto producto) {
        NodoCircular nuevo = new NodoCircular(producto);
        
        if (cabeza == null) {
            cabeza = nuevo;
            nuevo.setSiguiente(nuevo);
            actual = cabeza;
        } else {
            NodoCircular temp = cabeza;
            while (temp.getSiguiente() != cabeza) {
                temp = temp.getSiguiente();
            }
            temp.setSiguiente(nuevo);
            nuevo.setSiguiente(cabeza);
        }
        tamano++;
    }

    public void avanzar() {
        if (actual != null) {
            actual = actual.getSiguiente();
        }
    }

    public Producto obtenerActual() {
        return actual != null ? actual.getDato() : null;
    }

    public void imprimirCompleta() {
        if (cabeza == null) {
            System.out.println("Lista vacía");
            return;
        }

        System.out.println("\n=== LISTA CIRCULAR DE PRODUCTOS ===");
        NodoCircular temp = cabeza;
        do {
            System.out.println(temp.getDato());
            temp = temp.getSiguiente();
        } while (temp != cabeza);
        System.out.println("Total: " + tamano + " productos\n");
    }

    public Producto[] toArray() {
        if (cabeza == null) return new Producto[0];
        
        Producto[] array = new Producto[tamano];
        NodoCircular temp = cabeza;
        int i = 0;
        
        do {
            array[i++] = temp.getDato();
            temp = temp.getSiguiente();
        } while (temp != cabeza);
        
        return array;
    }

    private void fromArray(Producto[] array) {
        cabeza = null;
        actual = null;
        tamano = 0;
        for (Producto p : array) {
            agregar(p);
        }
    }

    // ==================== PREGUNTA 4A: BUBBLE SORT POR PRECIO ====================
    
    /**
     * ✅ SOLUCIÓN 4A: Ordenar por precio (Bubble Sort) - Ascendente
     */
    public void ordenarPorPrecioBubbleSort() {
        if (tamano <= 1) return;
        
        // Convertir a array
        Producto[] array = toArray();
        
        // Bubble Sort por precio (menor a mayor)
        for (int i = 0; i < array.length - 1; i++) {
            for (int j = 0; j < array.length - 1 - i; j++) {
                if (array[j].getPrecio() > array[j + 1].getPrecio()) {
                    // Intercambiar
                    Producto temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }
        
        // Reconstruir lista circular
        fromArray(array);
    }

    // ==================== PREGUNTA 4B: QUICK SORT POR CATEGORÍA Y NOMBRE ====================
    
    /**
     * ✅ SOLUCIÓN 4B: Ordenar por categoría y luego por nombre (Quick Sort)
     */
    public void ordenarPorCategoriaYNombre() {
        if (tamano <= 1) return;
        
        Producto[] array = toArray();
        quickSortRecursivo(array, 0, array.length - 1);
        fromArray(array);
    }

    private void quickSortRecursivo(Producto[] array, int inicio, int fin) {
        if (inicio < fin) {
            int indicePivote = particion(array, inicio, fin);
            quickSortRecursivo(array, inicio, indicePivote - 1);
            quickSortRecursivo(array, indicePivote + 1, fin);
        }
    }

    private int particion(Producto[] array, int inicio, int fin) {
        Producto pivote = array[fin];
        int i = inicio - 1;
        
        for (int j = inicio; j < fin; j++) {
            // Comparar primero por categoría, luego por nombre
            int comparacion = array[j].getCategoria().compareToIgnoreCase(pivote.getCategoria());
            
            if (comparacion < 0) {
                // Categoría menor
                i++;
                intercambiar(array, i, j);
            } else if (comparacion == 0) {
                // Misma categoría, comparar por nombre
                if (array[j].getNombre().compareToIgnoreCase(pivote.getNombre()) <= 0) {
                    i++;
                    intercambiar(array, i, j);
                }
            }
        }
        
        intercambiar(array, i + 1, fin);
        return i + 1;
    }

    private void intercambiar(Producto[] array, int i, int j) {
        Producto temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    // ==================== PREGUNTA 5A: BUSCAR POR CATEGORÍA ====================
    
    /**
     * ✅ SOLUCIÓN 5A: Buscar productos por categoría
     */
    public Producto[] buscarPorCategoria(String categoria) {
        if (cabeza == null) return new Producto[0];
        
        // PASADA 1: Contar coincidencias
        int contador = 0;
        NodoCircular temp = cabeza;
        
        do {
            if (temp.getDato().getCategoria().equalsIgnoreCase(categoria)) {
                contador++;
            }
            temp = temp.getSiguiente();
        } while (temp != cabeza);
        
        // Crear array del tamaño exacto
        Producto[] resultado = new Producto[contador];
        
        // PASADA 2: Llenar array
        temp = cabeza;
        int indice = 0;
        
        do {
            if (temp.getDato().getCategoria().equalsIgnoreCase(categoria)) {
                resultado[indice++] = temp.getDato();
            }
            temp = temp.getSiguiente();
        } while (temp != cabeza);
        
        return resultado;
    }

    // ==================== PREGUNTA 5B: BUSCAR STOCK BAJO ====================
    
    /**
     * ✅ SOLUCIÓN 5B: Buscar productos con stock bajo
     */
    public Producto[] buscarStockBajo(int stockMinimo) {
        if (cabeza == null) return new Producto[0];
        
        // PASADA 1: Contar
        int contador = 0;
        NodoCircular temp = cabeza;
        
        do {
            if (temp.getDato().getStock() < stockMinimo) {
                contador++;
            }
            temp = temp.getSiguiente();
        } while (temp != cabeza);
        
        // Crear array
        Producto[] resultado = new Producto[contador];
        
        // PASADA 2: Llenar
        temp = cabeza;
        int indice = 0;
        
        do {
            if (temp.getDato().getStock() < stockMinimo) {
                resultado[indice++] = temp.getDato();
            }
            temp = temp.getSiguiente();
        } while (temp != cabeza);
        
        return resultado;
    }

    // ==================== PREGUNTA 6A: ROTAR LISTA ====================
    
    /**
     * ✅ SOLUCIÓN 6A: Rotar la lista N posiciones
     */
    public void rotar(int posiciones) {
        if (cabeza == null || tamano <= 1 || posiciones <= 0) return;
        
        // Normalizar posiciones (si es mayor que el tamaño)
        posiciones = posiciones % tamano;
        
        if (posiciones == 0) return;
        
        // Mover la cabeza N posiciones hacia adelante
        for (int i = 0; i < posiciones; i++) {
            cabeza = cabeza.getSiguiente();
        }
        
        // Actualizar actual también
        actual = cabeza;
    }

    // ==================== PREGUNTA 6B: ELIMINAR ACTUAL ====================
    
    /**
     * ✅ SOLUCIÓN 6B: Eliminar producto actual y avanzar
     */
    public Producto eliminarActual() {
        if (actual == null) return null;
        
        Producto eliminado = actual.getDato();
        
        // Caso 1: Único elemento en la lista
        if (cabeza.getSiguiente() == cabeza) {
            cabeza = null;
            actual = null;
            tamano = 0;
            return eliminado;
        }
        
        // Caso 2: Múltiples elementos
        // Buscar el nodo anterior al actual
        NodoCircular anterior = cabeza;
        while (anterior.getSiguiente() != actual) {
            anterior = anterior.getSiguiente();
        }
        
        // Si actual es la cabeza, actualizar cabeza
        if (actual == cabeza) {
            cabeza = cabeza.getSiguiente();
        }
        
        // Eliminar el nodo actual
        anterior.setSiguiente(actual.getSiguiente());
        
        // Mover actual al siguiente
        actual = actual.getSiguiente();
        
        tamano--;
        return eliminado;
    }

    // ==================== PREGUNTA 6C: CONTAR EN RANGO DE PRECIO ====================
    
    /**
     * ✅ SOLUCIÓN 6C: Contar productos en rango de precio
     */
    public int contarEnRangoDePrecio(double precioMin, double precioMax) {
        if (cabeza == null) return 0;
        
        int contador = 0;
        NodoCircular temp = cabeza;
        
        do {
            double precio = temp.getDato().getPrecio();
            if (precio >= precioMin && precio <= precioMax) {
                contador++;
            }
            temp = temp.getSiguiente();
        } while (temp != cabeza);
        
        return contador;
    }

    // ==================== GETTERS ====================
    
    public int getTamano() {
        return tamano;
    }

    public NodoCircular getCabeza() {
        return cabeza;
    }

    public NodoCircular getActual() {
        return actual;
    }
}
