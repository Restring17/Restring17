package Ejercicio3;

/**
 *
 * @author User
 */
public class ListaEnlazadaStringUsar implements ListaEnlazadaString {
    private NodoString cabeza;

    public ListaEnlazadaStringUsar() {
        cabeza = null;
    }

    @Override
    public void agregarInicio(String valor) {
        NodoString nuevo = new NodoString(valor);
        nuevo.siguiente = cabeza;
        cabeza = nuevo;
    }

    @Override
    public void agregarFinal(String valor) {
        NodoString nuevo = new NodoString(valor);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            NodoString actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevo;
        }
    }

    @Override
    public boolean eliminar(String valor) {
        if (cabeza == null) return false;
        if (cabeza.valor.equals(valor)) {
            cabeza = cabeza.siguiente;
            return true;
        }
        NodoString actual = cabeza;
        while (actual.siguiente != null && !actual.siguiente.valor.equals(valor)) {
            actual = actual.siguiente;
        }
        if (actual.siguiente == null) return false;
        actual.siguiente = actual.siguiente.siguiente;
        return true;
    }

    @Override
    public boolean contiene(String valor) {
        NodoString actual = cabeza;
        while (actual != null) {
            if (actual.valor.equals(valor)) return true;
            actual = actual.siguiente;
        }
        return false;
    }

    @Override
    public boolean contieneOrdenado(String valor) {
        NodoString actual = cabeza;
        while (actual != null) {
            if (actual.valor.equals(valor)) {
                return true;
            } else if (actual.valor.compareTo(valor) > 0) {
                return false;
            }
            actual = actual.siguiente;
        }
        return false;
    }

    @Override
    public void imprimir() {
        NodoString actual = cabeza;
        while (actual != null) {
            System.out.print("- \"" + actual.valor + "\"");
            actual = actual.siguiente;
        }
        System.out.println(" - null");
    }

    @Override
    public void OrdenarBubbleSort() {
        if (cabeza == null || cabeza.siguiente == null) return;
        boolean huboIntercambio;
        do {
            NodoString actual = cabeza;
            NodoString siguiente = cabeza.siguiente;
            huboIntercambio = false;
            while (siguiente != null) {
                if (actual.getValor().compareTo(siguiente.getValor()) > 0) {
                    String temp = actual.getValor();
                    actual.setValor(siguiente.getValor());
                    siguiente.setValor(temp);
                    huboIntercambio = true;
                }
                actual = siguiente;
                siguiente = siguiente.getSiguiente();
            }
        } while (huboIntercambio);
    }

    @Override
    public void OrdenarSelectionSort() {
        if (cabeza == null || cabeza.siguiente == null) return;
        
        NodoString actual = cabeza;
        
        while (actual != null) {
            NodoString minNodo = actual;
            NodoString temp = actual.siguiente;
            
            while (temp != null) {
                if (temp.getValor().compareTo(minNodo.getValor()) < 0) {
                    minNodo = temp;
                }
                temp = temp.siguiente;
            }
            
            if (minNodo != actual) {
                String valorTemp = actual.getValor();
                actual.setValor(minNodo.getValor());
                minNodo.setValor(valorTemp);
            }
            
            actual = actual.siguiente;
        }
    }

    @Override
    public void OrdenarMergeSort() {
        cabeza = mergeSort(cabeza);
    }
    
    private NodoString mergeSort(NodoString inicio) {
        if (inicio == null || inicio.getSiguiente() == null) {
            return inicio;
        }

        NodoString medio = obtenerMitad(inicio);
        NodoString segundaMitad = medio.getSiguiente();
        medio.setSiguiente(null);

        NodoString izquierda = mergeSort(inicio);
        NodoString derecha = mergeSort(segundaMitad);

        return fusionar(izquierda, derecha);
    }
    
    private NodoString obtenerMitad(NodoString inicio) {
        NodoString lento = inicio;
        NodoString rapido = inicio.getSiguiente();

        while (rapido != null && rapido.getSiguiente() != null) {
            lento = lento.getSiguiente();
            rapido = rapido.getSiguiente().getSiguiente();
        }

        return lento;
    }

    private NodoString fusionar(NodoString l1, NodoString l2) {
        NodoString dummy = new NodoString("");
        NodoString actual = dummy;

        while (l1 != null && l2 != null) {
            if (l1.getValor().compareTo(l2.getValor()) <= 0) {
                actual.setSiguiente(l1);
                l1 = l1.getSiguiente();
            } else {
                actual.setSiguiente(l2);
                l2 = l2.getSiguiente();
            }
            actual = actual.getSiguiente();
        }

        if (l1 != null) actual.setSiguiente(l1);
        if (l2 != null) actual.setSiguiente(l2);

        return dummy.getSiguiente();
    }

    @Override
    public void OrdenarQuickSort() {
        cabeza = quickSort(cabeza, obtenerUltimo(cabeza));
    }
    
    private NodoString obtenerUltimo(NodoString nodo) {
        if (nodo == null) return null;
        while (nodo.siguiente != null) {
            nodo = nodo.siguiente;
        }
        return nodo;
    }
    
    private NodoString quickSort(NodoString inicio, NodoString fin) {
        if (inicio == null || inicio == fin) {
            return inicio;
        }
        
        NodoString[] resultado = particionar(inicio, fin);
        NodoString pivote = resultado[0];
        NodoString nuevaInicio = resultado[1];
        
        if (nuevaInicio != pivote) {
            NodoString temp = nuevaInicio;
            while (temp.siguiente != pivote) {
                temp = temp.siguiente;
            }
            temp.siguiente = null;
            
            nuevaInicio = quickSort(nuevaInicio, temp);
            
            temp = obtenerUltimo(nuevaInicio);
            temp.siguiente = pivote;
        }
        
        pivote.siguiente = quickSort(pivote.siguiente, fin);
        
        return nuevaInicio;
    }
    
    private NodoString[] particionar(NodoString inicio, NodoString fin) {
        NodoString pivote = fin;
        NodoString anterior = null;
        NodoString actual = inicio;
        NodoString cola = pivote;
        
        while (actual != pivote) {
            if (actual.getValor().compareTo(pivote.getValor()) < 0) {
                if (anterior == null) {
                    inicio = actual;
                }
                anterior = actual;
                actual = actual.siguiente;
            } else {
                if (anterior != null) {
                    anterior.siguiente = actual.siguiente;
                }
                NodoString temp = actual.siguiente;
                actual.siguiente = null;
                cola.siguiente = actual;
                cola = actual;
                actual = temp;
            }
        }
        
        if (anterior == null) {
            inicio = pivote;
        } else {
            anterior.siguiente = pivote;
        }
        
        return new NodoString[]{pivote, inicio};
    }

    @Override
    public void OrdenarInsertionSort() {
        if (cabeza == null || cabeza.siguiente == null) return;
        
        NodoString ordenada = null;
        NodoString actual = cabeza;
        
        while (actual != null) {
            NodoString siguiente = actual.siguiente;
            
            if (ordenada == null || ordenada.getValor().compareTo(actual.getValor()) >= 0) {
                actual.siguiente = ordenada;
                ordenada = actual;
            } else {
                NodoString temp = ordenada;
                while (temp.siguiente != null && temp.siguiente.getValor().compareTo(actual.getValor()) < 0) {
                    temp = temp.siguiente;
                }
                actual.siguiente = temp.siguiente;
                temp.siguiente = actual;
            }
            
            actual = siguiente;
        }
        
        cabeza = ordenada;
    }
}
