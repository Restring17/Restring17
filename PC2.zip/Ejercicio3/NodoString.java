package Ejercicio3;

/**
 *
 * @author User
 */
public class NodoString {
    NodoString siguiente;
    String valor;

    public NodoString(String valor) {
        this.valor = valor;
        this.siguiente = null;
    }

    public NodoString getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoString siguiente) {
        this.siguiente = siguiente;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }
}
