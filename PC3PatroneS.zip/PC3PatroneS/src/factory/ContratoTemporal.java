package factory;

import enums.CondicionContrato;

public class ContratoTemporal implements Contrato {
    private final int supervisionObras;
    private final int supervisionVias;
    
    public ContratoTemporal(int supervisionObras, int supervisionVias) {
        this.supervisionObras = supervisionObras;
        this.supervisionVias = supervisionVias;
    }
    
    @Override
    public CondicionContrato obtenerCondicion() {
        return CondicionContrato.CONTRATADO;
    }
    
    @Override
    public int getSupervisionObras() {
        return supervisionObras;
    }
    
    @Override
    public int getSupervisionVias() {
        return supervisionVias;
    }
}
