package Ejercicio5_ListaCircularPokemon;

/**
 * Nodo circular para Pokemon
 * @author User
 */
public class NodoCircularPokemon {
    private Pokemon pokemon;
    private NodoCircularPokemon siguiente;

    public NodoCircularPokemon(Pokemon pokemon) {
        this.pokemon = pokemon;
        this.siguiente = null;
    }

    public Pokemon getPokemon() {
        return pokemon;
    }

    public void setPokemon(Pokemon pokemon) {
        this.pokemon = pokemon;
    }

    public NodoCircularPokemon getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoCircularPokemon siguiente) {
        this.siguiente = siguiente;
    }
}
