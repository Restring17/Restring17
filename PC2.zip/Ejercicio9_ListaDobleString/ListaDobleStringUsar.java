package Ejercicio9_ListaDobleString;

/**
 * Lista doblemente enlazada de String con algoritmos de ordenamiento
 * Basada en Laboratorio09_EstacionesTren
 */
public class ListaDobleStringUsar implements ListaDobleString {
    private NodoDobleString cabeza;
    private NodoDobleString cola;
    private int tamanio;

    public ListaDobleStringUsar() {
        this.cabeza = null;
        this.cola = null;
        this.tamanio = 0;
    }

    @Override
    public void agregarInicio(String valor) {
        NodoDobleString nuevo = new NodoDobleString(valor);
        if (cabeza == null) {
            cabeza = cola = nuevo;
        } else {
            nuevo.setSiguiente(cabeza);
            cabeza.setAnterior(nuevo);
            cabeza = nuevo;
        }
        tamanio++;
    }

    @Override
    public void agregarFinal(String valor) {
        NodoDobleString nuevo = new NodoDobleString(valor);
        if (cola == null) {
            cabeza = cola = nuevo;
        } else {
            cola.setSiguiente(nuevo);
            nuevo.setAnterior(cola);
            cola = nuevo;
        }
        tamanio++;
    }

    @Override
    public boolean eliminar(String valor) {
        if (cabeza == null) return false;
        NodoDobleString temp = cabeza;
        while (temp != null) {
            if (temp.getValor().equals(valor)) {
                if (temp == cabeza) cabeza = temp.getSiguiente();
                if (temp == cola) cola = temp.getAnterior();
                if (temp.getAnterior() != null) temp.getAnterior().setSiguiente(temp.getSiguiente());
                if (temp.getSiguiente() != null) temp.getSiguiente().setAnterior(temp.getAnterior());
                tamanio--;
                return true;
            }
            temp = temp.getSiguiente();
        }
        return false;
    }

    @Override
    public boolean contiene(String valor) {
        NodoDobleString temp = cabeza;
        while (temp != null) {
            if (temp.getValor().equals(valor)) return true;
            temp = temp.getSiguiente();
        }
        return false;
    }

    @Override
    public void imprimirAdelante() {
        System.out.print("null <- ");
        NodoDobleString temp = cabeza;
        while (temp != null) {
            System.out.print("\"" + temp.getValor() + "\" <-> ");
            temp = temp.getSiguiente();
        }
        System.out.println("null");
    }

    @Override
    public void imprimirAtras() {
        System.out.print("null -> ");
        NodoDobleString temp = cola;
        while (temp != null) {
            System.out.print("\"" + temp.getValor() + "\" <-> ");
            temp = temp.getAnterior();
        }
        System.out.println("null");
    }

    @Override
    public boolean estaVacia() {
        return cabeza == null;
    }

    @Override
    public int tamanio() {
        return tamanio;
    }

    @Override
    public void OrdenarBubbleSort() {
        if (cabeza == null || cabeza.getSiguiente() == null) return;
        boolean huboIntercambio;
        do {
            huboIntercambio = false;
            NodoDobleString temp = cabeza;
            while (temp.getSiguiente() != null) {
                if (temp.getValor().compareTo(temp.getSiguiente().getValor()) > 0) {
                    String valorTemp = temp.getValor();
                    temp.setValor(temp.getSiguiente().getValor());
                    temp.getSiguiente().setValor(valorTemp);
                    huboIntercambio = true;
                }
                temp = temp.getSiguiente();
            }
        } while (huboIntercambio);
    }

    @Override
    public void OrdenarSelectionSort() {
        if (cabeza == null || cabeza.getSiguiente() == null) return;
        NodoDobleString i = cabeza;
        while (i != null) {
            NodoDobleString minNodo = i;
            NodoDobleString j = i.getSiguiente();
            while (j != null) {
                if (j.getValor().compareTo(minNodo.getValor()) < 0) minNodo = j;
                j = j.getSiguiente();
            }
            if (minNodo != i) {
                String temp = i.getValor();
                i.setValor(minNodo.getValor());
                minNodo.setValor(temp);
            }
            i = i.getSiguiente();
        }
    }

    @Override
    public void OrdenarInsertionSort() {
        if (cabeza == null || cabeza.getSiguiente() == null) return;
        NodoDobleString ordenada = null;
        NodoDobleString current = cabeza;
        while (current != null) {
            NodoDobleString siguiente = current.getSiguiente();
            current.setAnterior(null);
            current.setSiguiente(null);
            ordenada = insertarOrdenado(ordenada, current);
            current = siguiente;
        }
        cabeza = ordenada;
        cola = cabeza;
        if (cola != null) while (cola.getSiguiente() != null) cola = cola.getSiguiente();
    }

    private NodoDobleString insertarOrdenado(NodoDobleString ordenada, NodoDobleString nuevo) {
        if (ordenada == null || ordenada.getValor().compareTo(nuevo.getValor()) >= 0) {
            nuevo.setSiguiente(ordenada);
            if (ordenada != null) ordenada.setAnterior(nuevo);
            return nuevo;
        }
        NodoDobleString temp = ordenada;
        while (temp.getSiguiente() != null && temp.getSiguiente().getValor().compareTo(nuevo.getValor()) < 0) {
            temp = temp.getSiguiente();
        }
        nuevo.setSiguiente(temp.getSiguiente());
        if (temp.getSiguiente() != null) temp.getSiguiente().setAnterior(nuevo);
        temp.setSiguiente(nuevo);
        nuevo.setAnterior(temp);
        return ordenada;
    }

    @Override
    public void OrdenarMergeSort() {
        cabeza = mergeSort(cabeza);
        cola = cabeza;
        if (cola != null) while (cola.getSiguiente() != null) cola = cola.getSiguiente();
    }

    private NodoDobleString mergeSort(NodoDobleString inicio) {
        if (inicio == null || inicio.getSiguiente() == null) return inicio;
        NodoDobleString medio = obtenerMitad(inicio);
        NodoDobleString segundaMitad = medio.getSiguiente();
        medio.setSiguiente(null);
        if (segundaMitad != null) segundaMitad.setAnterior(null);
        return fusionar(mergeSort(inicio), mergeSort(segundaMitad));
    }

    private NodoDobleString obtenerMitad(NodoDobleString inicio) {
        if (inicio == null) return null;
        NodoDobleString lento = inicio, rapido = inicio;
        while (rapido.getSiguiente() != null && rapido.getSiguiente().getSiguiente() != null) {
            lento = lento.getSiguiente();
            rapido = rapido.getSiguiente().getSiguiente();
        }
        return lento;
    }

    private NodoDobleString fusionar(NodoDobleString l1, NodoDobleString l2) {
        if (l1 == null) return l2;
        if (l2 == null) return l1;
        if (l1.getValor().compareTo(l2.getValor()) <= 0) {
            l1.setSiguiente(fusionar(l1.getSiguiente(), l2));
            if (l1.getSiguiente() != null) l1.getSiguiente().setAnterior(l1);
            l1.setAnterior(null);
            return l1;
        } else {
            l2.setSiguiente(fusionar(l1, l2.getSiguiente()));
            if (l2.getSiguiente() != null) l2.getSiguiente().setAnterior(l2);
            l2.setAnterior(null);
            return l2;
        }
    }

    @Override
    public void OrdenarQuickSort() {
        cabeza = quickSort(cabeza);
        cola = cabeza;
        if (cola != null) while (cola.getSiguiente() != null) cola = cola.getSiguiente();
    }

    private NodoDobleString quickSort(NodoDobleString inicio) {
        if (inicio == null || inicio.getSiguiente() == null) return inicio;
        NodoDobleString pivote = inicio;
        NodoDobleString menores = null, mayores = null, temp = inicio.getSiguiente();
        while (temp != null) {
            NodoDobleString siguiente = temp.getSiguiente();
            temp.setSiguiente(null);
            temp.setAnterior(null);
            if (temp.getValor().compareTo(pivote.getValor()) < 0) {
                temp.setSiguiente(menores);
                if (menores != null) menores.setAnterior(temp);
                menores = temp;
            } else {
                temp.setSiguiente(mayores);
                if (mayores != null) mayores.setAnterior(temp);
                mayores = temp;
            }
            temp = siguiente;
        }
        menores = quickSort(menores);
        mayores = quickSort(mayores);
        if (menores == null) {
            pivote.setSiguiente(mayores);
            if (mayores != null) mayores.setAnterior(pivote);
            return pivote;
        }
        NodoDobleString fin = menores;
        while (fin.getSiguiente() != null) fin = fin.getSiguiente();
        fin.setSiguiente(pivote);
        pivote.setAnterior(fin);
        pivote.setSiguiente(mayores);
        if (mayores != null) mayores.setAnterior(pivote);
        return menores;
    }
}
