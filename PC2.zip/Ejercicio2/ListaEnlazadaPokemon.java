package Ejercicio2;

/**
 *
 * @author User
 */
public interface ListaEnlazadaPokemon {
    void agregarInicio(Pokemon pokemon);
    void agregarFinal(Pokemon pokemon);
    boolean eliminar(String nombre);
    boolean contiene(String nombre);
    boolean contieneOrdenado(String nombre);
    void imprimir();
    
    //Ordenamiento por poder
    void OrdenarBubbleSortPorPoder();
    void OrdenarSelectionSortPorPoder();
    void OrdenarMergeSortPorPoder();
    void OrdenarQuickSortPorPoder();
    void OrdenarInsertionSortPorPoder();
    
    //Ordenamiento por nombre
    void OrdenarBubbleSortPorNombre();
    void OrdenarSelectionSortPorNombre();
    void OrdenarMergeSortPorNombre();
    void OrdenarQuickSortPorNombre();
    void OrdenarInsertionSortPorNombre();
}
