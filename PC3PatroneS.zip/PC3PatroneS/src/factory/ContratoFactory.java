package factory;

import enums.CondicionContrato;

public class ContratoFactory {
    
    public static Contrato crearContrato(CondicionContrato condicion, 
                                         int supervisionObras, 
                                         int supervisionVias) {
        switch (condicion) {
            case ESTABLE:
                return new ContratoEstable(supervisionObras, supervisionVias);
            case CONTRATADO:
                return new ContratoTemporal(supervisionObras, supervisionVias);
            default:
                throw new IllegalArgumentException("Tipo de contrato no válido");
        }
    }
}
