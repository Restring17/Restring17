package Ejercicio9_ListaDobleString;

public interface ListaDobleString {
    void agregarInicio(String valor);
    void agregarFinal(String valor);
    boolean eliminar(String valor);
    boolean contiene(String valor);
    void imprimirAdelante();
    void imprimirAtras();
    boolean estaVacia();
    int tamanio();
    
    void OrdenarBubbleSort();
    void OrdenarSelectionSort();
    void OrdenarMergeSort();
    void OrdenarQuickSort();
    void OrdenarInsertionSort();
}
