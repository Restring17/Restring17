package PC1;

/**
 *
 * @author User
 */
public class Email implements CanalNotificacion {
    @Override
    public void enviar(Mensaje mensaje) {
        System.out.println("Enviando por Email: " + mensaje.getContenido());
    }
}