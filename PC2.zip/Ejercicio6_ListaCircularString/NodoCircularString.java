package Ejercicio6_ListaCircularString;

public class NodoCircularString {
    private String valor;
    private NodoCircularString siguiente;

    public NodoCircularString(String valor) {
        this.valor = valor;
        this.siguiente = null;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public NodoCircularString getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoCircularString siguiente) {
        this.siguiente = siguiente;
    }
}
