

import enums.CondicionContrato;
import enums.Especialidad;
import factory.Contrato;
import factory.ContratoFactory;
import modelo.Arquitecto;

public class Main {
    
    public static void main(String[] args) {
        System.out.println("=========================================================");
        System.out.println("||          SISTEMA DE GESTIÓN DE ARQUITECTOS - UTP              ||");
        System.out.println("==============================================================\n");
        
        System.out.println("CASO 1: Arquitecto con Contrato Estable");
        System.out.println("--------------------------------------------");
        
        Contrato contratoEstable = ContratoFactory.crearContrato(
            CondicionContrato.ESTABLE, 2, 1
        );
        
        Arquitecto arq1 = new Arquitecto.Builder()
            .conCodigo("ARQ001")
            .conNombres("Juan Carlos Pérez López")
            .conContrato(contratoEstable)
            .conEspecialidad(Especialidad.ESTRUCTURAS)
            .conNumeroObras(15)
            .conDescuentoAFP()
            .build();
        
        arq1.mostrarInformacion();
        
        System.out.println("\nCASO 2: Arquitecto con Contrato Temporal");
        System.out.println("--------------------------------------------");
        
        Contrato contratoTemporal = ContratoFactory.crearContrato(
            CondicionContrato.CONTRATADO, 3, 2
        );
        
        Arquitecto arq2 = new Arquitecto.Builder()
            .conCodigo("ARQ002")
            .conNombres("María Elena Rodríguez Sánchez")
            .conContrato(contratoTemporal)
            .conEspecialidad(Especialidad.RECURSOS_HIDRICOS)
            .conNumeroObras(20)
            .conDescuentoSNP()
            .build();
        
        arq2.mostrarInformacion();
        
        System.out.println("\nCASO 3: Arquitecto de Ingeniería Vial");
        System.out.println("--------------------------------------------");
        
        Contrato contratoEstable2 = ContratoFactory.crearContrato(
            CondicionContrato.ESTABLE, 1, 2
        );
        
        Arquitecto arq3 = new Arquitecto.Builder()
            .conCodigo("ARQ003")
            .conNombres("Pedro Antonio Gutiérrez Mendoza")
            .conContrato(contratoEstable2)
            .conEspecialidad(Especialidad.INGENIERIA_VIAL)
            .conNumeroObras(18)
            .conDescuentoAFP()
            .build();
        
        arq3.mostrarInformacion();
        
        System.out.println("\nCASO 4: Arquitecto Temporal con Pocas Obras");
        System.out.println("--------------------------------------------");
        
        Contrato contratoTemporal2 = ContratoFactory.crearContrato(
            CondicionContrato.CONTRATADO, 1, 1
        );
        
        Arquitecto arq4 = new Arquitecto.Builder()
            .conCodigo("ARQ004")
            .conNombres("Ana Lucía Torres Vargas")
            .conContrato(contratoTemporal2)
            .conEspecialidad(Especialidad.ESTRUCTURAS)
            .conNumeroObras(10)
            .conDescuentoSNP()
            .build();
        
        arq4.mostrarInformacion();
    }
}
