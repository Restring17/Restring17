package Ejercicio4_ListaCircularInt;

/**
 * Nodo de una lista circular que almacena un valor entero
 * @author User
 */
public class NodoCircularInt {
    private int valor;
    private NodoCircularInt siguiente;

    public NodoCircularInt(int valor) {
        this.valor = valor;
        this.siguiente = null;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public NodoCircularInt getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoCircularInt siguiente) {
        this.siguiente = siguiente;
    }
}
