package PC1;

/**
 *
 * @author User
 */
public class Recordatorio extends Mensaje {
    public Recordatorio(String contenido) {
        super(contenido, "Recordatorio");
    }
}