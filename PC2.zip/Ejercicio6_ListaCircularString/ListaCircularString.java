package Ejercicio6_ListaCircularString;

public interface ListaCircularString {
    void agregar(String valor);
    void agregarInicio(String valor);
    boolean eliminar(String valor);
    boolean contiene(String valor);
    void imprimir();
    void imprimirCompleta();
    void avanzar();
    String obtenerActual();
    boolean estaVacia();
    int tamanio();
    
    void OrdenarBubbleSort();
    void OrdenarSelectionSort();
    void OrdenarMergeSort();
    void OrdenarQuickSort();
    void OrdenarInsertionSort();
}
