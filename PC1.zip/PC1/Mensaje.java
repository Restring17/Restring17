package PC1;

/**
 *
 * @author User
 */
public abstract class Mensaje {
    protected String contenido;
    protected String tipo;
    
    public Mensaje(String contenido, String tipo) {
        this.contenido = contenido;
        this.tipo = tipo;
    }
    
    public String getContenido() {
        return contenido;
    }
    
    public String getTipo() {
        return tipo;
    }
}