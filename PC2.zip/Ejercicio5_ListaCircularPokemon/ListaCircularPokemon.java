package Ejercicio5_ListaCircularPokemon;

/**
 * Interfaz para lista circular de Pokemon
 * @author User
 */
public interface ListaCircularPokemon {
    void agregar(Pokemon pokemon);
    void agregarInicio(Pokemon pokemon);
    boolean eliminar(String nombre);
    boolean contiene(String nombre);
    void imprimir();
    void imprimirCompleta();
    void avanzar();
    Pokemon obtenerActual();
    boolean estaVacia();
    int tamanio();
    
    // Ordenamiento por poder
    void OrdenarBubbleSortPorPoder();
    void OrdenarSelectionSortPorPoder();
    void OrdenarMergeSortPorPoder();
    void OrdenarQuickSortPorPoder();
    void OrdenarInsertionSortPorPoder();
    
    // Ordenamiento por nombre
    void OrdenarBubbleSortPorNombre();
    void OrdenarSelectionSortPorNombre();
    void OrdenarMergeSortPorNombre();
    void OrdenarQuickSortPorNombre();
    void OrdenarInsertionSortPorNombre();
}
