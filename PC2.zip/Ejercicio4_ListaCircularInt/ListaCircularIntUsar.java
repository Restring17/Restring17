package Ejercicio4_ListaCircularInt;

/**
 * Implementación de lista circular de enteros con algoritmos de ordenamiento
 * @author User
 */
public class ListaCircularIntUsar implements ListaCircularInt {
    private NodoCircularInt cabeza;
    private NodoCircularInt actual; // Nodo actual para navegación circular
    private int tamanio;

    public ListaCircularIntUsar() {
        this.cabeza = null;
        this.actual = null;
        this.tamanio = 0;
    }

    @Override
    public void agregar(int valor) {
        NodoCircularInt nuevo = new NodoCircularInt(valor);
        if (cabeza == null) {
            cabeza = nuevo;
            nuevo.setSiguiente(cabeza); // Apunta a sí mismo
            actual = cabeza;
        } else {
            NodoCircularInt temp = cabeza;
            while (temp.getSiguiente() != cabeza) {
                temp = temp.getSiguiente();
            }
            temp.setSiguiente(nuevo);
            nuevo.setSiguiente(cabeza);
        }
        tamanio++;
    }

    @Override
    public void agregarInicio(int valor) {
        NodoCircularInt nuevo = new NodoCircularInt(valor);
        if (cabeza == null) {
            cabeza = nuevo;
            nuevo.setSiguiente(cabeza);
            actual = cabeza;
        } else {
            NodoCircularInt temp = cabeza;
            while (temp.getSiguiente() != cabeza) {
                temp = temp.getSiguiente();
            }
            nuevo.setSiguiente(cabeza);
            temp.setSiguiente(nuevo);
            cabeza = nuevo;
            actual = cabeza;
        }
        tamanio++;
    }

    @Override
    public boolean eliminar(int valor) {
        if (cabeza == null) return false;

        // Si es el único nodo
        if (cabeza.getSiguiente() == cabeza && cabeza.getValor() == valor) {
            cabeza = null;
            actual = null;
            tamanio--;
            return true;
        }

        // Si es la cabeza
        if (cabeza.getValor() == valor) {
            NodoCircularInt temp = cabeza;
            while (temp.getSiguiente() != cabeza) {
                temp = temp.getSiguiente();
            }
            temp.setSiguiente(cabeza.getSiguiente());
            cabeza = cabeza.getSiguiente();
            actual = cabeza;
            tamanio--;
            return true;
        }

        // Buscar en el resto
        NodoCircularInt temp = cabeza;
        do {
            if (temp.getSiguiente().getValor() == valor) {
                temp.setSiguiente(temp.getSiguiente().getSiguiente());
                if (actual.getValor() == valor) {
                    actual = temp.getSiguiente();
                }
                tamanio--;
                return true;
            }
            temp = temp.getSiguiente();
        } while (temp != cabeza);

        return false;
    }

    @Override
    public boolean contiene(int valor) {
        if (cabeza == null) return false;
        NodoCircularInt temp = cabeza;
        do {
            if (temp.getValor() == valor) return true;
            temp = temp.getSiguiente();
        } while (temp != cabeza);
        return false;
    }

    @Override
    public void imprimir() {
        if (cabeza == null) {
            System.out.println("Lista vacía");
            return;
        }
        NodoCircularInt temp = cabeza;
        System.out.print("Circular: ");
        do {
            System.out.print(temp.getValor() + " -> ");
            temp = temp.getSiguiente();
        } while (temp != cabeza);
        System.out.println("(cabeza)");
    }

    @Override
    public void imprimirCompleta() {
        if (cabeza == null) {
            System.out.println("Lista vacía");
            return;
        }
        NodoCircularInt temp = cabeza;
        System.out.print("Vuelta completa desde cabeza: ");
        do {
            System.out.print(temp.getValor() + " ");
            temp = temp.getSiguiente();
        } while (temp != cabeza);
        System.out.println();
    }

    @Override
    public void avanzar() {
        if (actual != null) {
            actual = actual.getSiguiente();
        }
    }

    @Override
    public int obtenerActual() {
        if (actual != null) {
            return actual.getValor();
        }
        throw new IllegalStateException("Lista vacía");
    }

    @Override
    public boolean estaVacia() {
        return cabeza == null;
    }

    @Override
    public int tamanio() {
        return tamanio;
    }

    // ==================== ALGORITMOS DE ORDENAMIENTO ====================

    @Override
    public void OrdenarBubbleSort() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        
        boolean huboIntercambio;
        do {
            huboIntercambio = false;
            NodoCircularInt temp = cabeza;
            do {
                NodoCircularInt siguiente = temp.getSiguiente();
                if (temp.getValor() > siguiente.getValor()) {
                    int valorTemp = temp.getValor();
                    temp.setValor(siguiente.getValor());
                    siguiente.setValor(valorTemp);
                    huboIntercambio = true;
                }
                temp = temp.getSiguiente();
            } while (temp.getSiguiente() != cabeza);
        } while (huboIntercambio);
    }

    @Override
    public void OrdenarSelectionSort() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        
        NodoCircularInt i = cabeza;
        do {
            NodoCircularInt minNodo = i;
            NodoCircularInt j = i.getSiguiente();
            
            while (j != cabeza) {
                if (j.getValor() < minNodo.getValor()) {
                    minNodo = j;
                }
                j = j.getSiguiente();
            }
            
            if (minNodo != i) {
                int temp = i.getValor();
                i.setValor(minNodo.getValor());
                minNodo.setValor(temp);
            }
            
            i = i.getSiguiente();
        } while (i.getSiguiente() != cabeza);
    }

    @Override
    public void OrdenarInsertionSort() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        
        // Convertir temporalmente a lista simple para ordenar
        NodoCircularInt ultimo = cabeza;
        while (ultimo.getSiguiente() != cabeza) {
            ultimo = ultimo.getSiguiente();
        }
        ultimo.setSiguiente(null); // Romper el ciclo temporalmente
        
        NodoCircularInt ordenada = null;
        NodoCircularInt current = cabeza;
        
        while (current != null) {
            NodoCircularInt siguiente = current.getSiguiente();
            
            if (ordenada == null || ordenada.getValor() >= current.getValor()) {
                current.setSiguiente(ordenada);
                ordenada = current;
            } else {
                NodoCircularInt temp = ordenada;
                while (temp.getSiguiente() != null && temp.getSiguiente().getValor() < current.getValor()) {
                    temp = temp.getSiguiente();
                }
                current.setSiguiente(temp.getSiguiente());
                temp.setSiguiente(current);
            }
            
            current = siguiente;
        }
        
        cabeza = ordenada;
        
        // Restaurar la circularidad
        ultimo = cabeza;
        while (ultimo.getSiguiente() != null) {
            ultimo = ultimo.getSiguiente();
        }
        ultimo.setSiguiente(cabeza);
        actual = cabeza;
    }

    @Override
    public void OrdenarMergeSort() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        
        // Romper circularidad
        NodoCircularInt ultimo = cabeza;
        while (ultimo.getSiguiente() != cabeza) {
            ultimo = ultimo.getSiguiente();
        }
        ultimo.setSiguiente(null);
        
        // Ordenar
        cabeza = mergeSort(cabeza);
        
        // Restaurar circularidad
        ultimo = cabeza;
        while (ultimo.getSiguiente() != null) {
            ultimo = ultimo.getSiguiente();
        }
        ultimo.setSiguiente(cabeza);
        actual = cabeza;
    }

    private NodoCircularInt mergeSort(NodoCircularInt inicio) {
        if (inicio == null || inicio.getSiguiente() == null) {
            return inicio;
        }

        NodoCircularInt medio = obtenerMitad(inicio);
        NodoCircularInt segundaMitad = medio.getSiguiente();
        medio.setSiguiente(null);

        NodoCircularInt izquierda = mergeSort(inicio);
        NodoCircularInt derecha = mergeSort(segundaMitad);

        return fusionar(izquierda, derecha);
    }

    private NodoCircularInt obtenerMitad(NodoCircularInt inicio) {
        if (inicio == null) return null;
        NodoCircularInt lento = inicio;
        NodoCircularInt rapido = inicio.getSiguiente();

        while (rapido != null && rapido.getSiguiente() != null) {
            lento = lento.getSiguiente();
            rapido = rapido.getSiguiente().getSiguiente();
        }

        return lento;
    }

    private NodoCircularInt fusionar(NodoCircularInt l1, NodoCircularInt l2) {
        NodoCircularInt dummy = new NodoCircularInt(0);
        NodoCircularInt current = dummy;

        while (l1 != null && l2 != null) {
            if (l1.getValor() <= l2.getValor()) {
                current.setSiguiente(l1);
                l1 = l1.getSiguiente();
            } else {
                current.setSiguiente(l2);
                l2 = l2.getSiguiente();
            }
            current = current.getSiguiente();
        }

        if (l1 != null) current.setSiguiente(l1);
        if (l2 != null) current.setSiguiente(l2);

        return dummy.getSiguiente();
    }

    @Override
    public void OrdenarQuickSort() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        
        // Romper circularidad
        NodoCircularInt ultimo = cabeza;
        while (ultimo.getSiguiente() != cabeza) {
            ultimo = ultimo.getSiguiente();
        }
        ultimo.setSiguiente(null);
        
        // Ordenar
        cabeza = quickSort(cabeza, ultimo);
        
        // Restaurar circularidad
        ultimo = cabeza;
        while (ultimo.getSiguiente() != null) {
            ultimo = ultimo.getSiguiente();
        }
        ultimo.setSiguiente(cabeza);
        actual = cabeza;
    }

    private NodoCircularInt quickSort(NodoCircularInt inicio, NodoCircularInt fin) {
        if (inicio == null || inicio == fin) {
            return inicio;
        }

        NodoCircularInt[] resultado = particionar(inicio, fin);
        NodoCircularInt pivote = resultado[0];
        NodoCircularInt nuevoInicio = resultado[1];

        if (nuevoInicio != pivote) {
            NodoCircularInt temp = nuevoInicio;
            while (temp.getSiguiente() != pivote) {
                temp = temp.getSiguiente();
            }
            temp.setSiguiente(null);

            nuevoInicio = quickSort(nuevoInicio, temp);

            temp = obtenerUltimo(nuevoInicio);
            temp.setSiguiente(pivote);
        }

        pivote.setSiguiente(quickSort(pivote.getSiguiente(), fin));

        return nuevoInicio;
    }

    private NodoCircularInt[] particionar(NodoCircularInt inicio, NodoCircularInt fin) {
        NodoCircularInt pivote = fin;
        NodoCircularInt anterior = null;
        NodoCircularInt current = inicio;
        NodoCircularInt cola = pivote;

        while (current != pivote) {
            if (current.getValor() < pivote.getValor()) {
                if (anterior == null) {
                    inicio = current;
                }
                anterior = current;
                current = current.getSiguiente();
            } else {
                if (anterior != null) {
                    anterior.setSiguiente(current.getSiguiente());
                }
                NodoCircularInt temp = current.getSiguiente();
                current.setSiguiente(null);
                cola.setSiguiente(current);
                cola = current;
                current = temp;
            }
        }

        if (anterior == null) {
            inicio = pivote;
        } else {
            anterior.setSiguiente(pivote);
        }

        return new NodoCircularInt[]{pivote, inicio};
    }

    private NodoCircularInt obtenerUltimo(NodoCircularInt nodo) {
        if (nodo == null) return null;
        while (nodo.getSiguiente() != null) {
            nodo = nodo.getSiguiente();
        }
        return nodo;
    }
}
