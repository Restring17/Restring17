package Ejercicio2;

public class Pokemon {
    private String nombre;
    private String tipo;
    private int poder;

    // Constructor completo
    public Pokemon(String nombre, String tipo, int poder) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.poder = poder;
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getPoder() {
        return poder;
    }

    public void setPoder(int poder) {
        this.poder = poder;
    }

    // Representación en texto
    @Override
    public String toString() {
        return nombre + " (" + tipo + ", Poder: " + poder + ")";
    }
}
