package PC1;

/**
 *
 * @author User
 */
public class Promocion extends Mensaje {
    public Promocion(String contenido) {
        super(contenido, "Promocion");
    }
}