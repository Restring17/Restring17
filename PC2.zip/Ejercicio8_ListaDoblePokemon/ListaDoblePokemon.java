package Ejercicio8_ListaDoblePokemon;

public interface ListaDoblePokemon {
    void agregarInicio(Pokemon pokemon);
    void agregarFinal(Pokemon pokemon);
    boolean eliminar(String nombre);
    boolean contiene(String nombre);
    void imprimirAdelante();
    void imprimirAtras();
    boolean estaVacia();
    int tamanio();
    
    void OrdenarBubbleSortPorPoder();
    void OrdenarSelectionSortPorPoder();
    void OrdenarMergeSortPorPoder();
    void OrdenarQuickSortPorPoder();
    void OrdenarInsertionSortPorPoder();
    
    void OrdenarBubbleSortPorNombre();
    void OrdenarSelectionSortPorNombre();
    void OrdenarMergeSortPorNombre();
    void OrdenarQuickSortPorNombre();
    void OrdenarInsertionSortPorNombre();
}
