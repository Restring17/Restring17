package Ejercicio7_ListaDobleInt;

public interface ListaDobleInt {
    void agregarInicio(int valor);
    void agregarFinal(int valor);
    boolean eliminar(int valor);
    boolean contiene(int valor);
    void imprimirAdelante();
    void imprimirAtras();
    boolean estaVacia();
    int tamanio();
    
    void OrdenarBubbleSort();
    void OrdenarSelectionSort();
    void OrdenarMergeSort();
    void OrdenarQuickSort();
    void OrdenarInsertionSort();
}
