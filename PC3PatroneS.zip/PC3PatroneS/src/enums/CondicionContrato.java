package enums;

public enum CondicionContrato {
    ESTABLE,
    CONTRATADO
}
