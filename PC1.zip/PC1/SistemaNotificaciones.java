package PC1;

/**
 *
 * @author User
 */
public class SistemaNotificaciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Crear gestor
        GestorNotificaciones gestor = new GestorNotificaciones();
        
        // Crear diferentes tipos de mensajes (LSP - Se pueden usar intercambiablemente)
        Mensaje alerta = new Alerta("Sistema caído - Acción requerida");
        Mensaje recordatorio = new Recordatorio("Reunión en 30 minutos");
        Mensaje promocion = new Promocion("Descuento del 50% hoy");
        
        // Crear canales
        CanalNotificacion email = new Email();
        CanalNotificacion sms = new SMS();
        CanalNotificacion push = new Push();
        CanalNotificacion whatsapp = new WhatsApp();
        
        // Enviar mensajes por diferentes canales
        System.out.println("=== ENVIANDO ALERTA ===");
        gestor.procesarEnvio(email, alerta);
        gestor.procesarEnvio(sms, alerta);
        
        System.out.println("\n=== ENVIANDO RECORDATORIO ===");
        gestor.procesarEnvio(push, recordatorio);
        
        System.out.println("\n=== ENVIANDO PROMOCIÓN ===");
        gestor.procesarEnvio(whatsapp, promocion);
        gestor.procesarEnvio(email, promocion);
    }
}
