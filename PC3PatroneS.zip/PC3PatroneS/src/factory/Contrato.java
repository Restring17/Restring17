package factory;

import enums.CondicionContrato;

public interface Contrato {
    CondicionContrato obtenerCondicion();
    int getSupervisionObras();
    int getSupervisionVias();
}
