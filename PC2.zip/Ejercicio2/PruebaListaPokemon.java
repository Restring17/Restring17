package Ejercicio2;

/**
 * Clase de prueba para la lista enlazada de Pokemon
 * @author User
 */
public class PruebaListaPokemon {
    public static void main(String[] args) {
        ListaEnlazadaPokemonUsar lista = new ListaEnlazadaPokemonUsar();
        
        // Agregar Pokemon
        System.out.println("=== AGREGANDO POKEMON ===");
        lista.agregarFinal(new Pokemon("Pikachu", "Eléctrico", 320));
        lista.agregarFinal(new Pokemon("Charizard", "Fuego", 534));
        lista.agregarFinal(new Pokemon("Blastoise", "Agua", 530));
        lista.agregarFinal(new Pokemon("Venusaur", "Planta", 525));
        lista.agregarFinal(new Pokemon("Alakazam", "Psíquico", 500));
        lista.agregarInicio(new Pokemon("Mewtwo", "Psíquico", 680));
        
        System.out.println("Lista original:");
        lista.imprimir();
        
        // Ordenar por poder usando diferentes algoritmos
        System.out.println("\n=== ORDENAMIENTO POR PODER ===");
        
        ListaEnlazadaPokemonUsar listaBubble = clonarLista(lista);
        System.out.println("\nBubble Sort por poder:");
        listaBubble.OrdenarBubbleSortPorPoder();
        listaBubble.imprimir();
        
        ListaEnlazadaPokemonUsar listaSelection = clonarLista(lista);
        System.out.println("\nSelection Sort por poder:");
        listaSelection.OrdenarSelectionSortPorPoder();
        listaSelection.imprimir();
        
        ListaEnlazadaPokemonUsar listaMerge = clonarLista(lista);
        System.out.println("\nMerge Sort por poder:");
        listaMerge.OrdenarMergeSortPorPoder();
        listaMerge.imprimir();
        
        ListaEnlazadaPokemonUsar listaQuick = clonarLista(lista);
        System.out.println("\nQuick Sort por poder:");
        listaQuick.OrdenarQuickSortPorPoder();
        listaQuick.imprimir();
        
        ListaEnlazadaPokemonUsar listaInsertion = clonarLista(lista);
        System.out.println("\nInsertion Sort por poder:");
        listaInsertion.OrdenarInsertionSortPorPoder();
        listaInsertion.imprimir();
        
        // Ordenar por nombre
        System.out.println("\n=== ORDENAMIENTO POR NOMBRE ===");
        
        ListaEnlazadaPokemonUsar listaNombre = clonarLista(lista);
        System.out.println("\nBubble Sort por nombre:");
        listaNombre.OrdenarBubbleSortPorNombre();
        listaNombre.imprimir();
        
        // Operaciones de búsqueda
        System.out.println("\n=== BÚSQUEDA ===");
        System.out.println("¿Contiene 'Pikachu'? " + lista.contiene("Pikachu"));
        System.out.println("¿Contiene 'Mew'? " + lista.contiene("Mew"));
        
        // Eliminar
        System.out.println("\n=== ELIMINACIÓN ===");
        System.out.println("Eliminando 'Charizard': " + lista.eliminar("Charizard"));
        lista.imprimir();
    }
    
    // Método auxiliar para clonar la lista
    private static ListaEnlazadaPokemonUsar clonarLista(ListaEnlazadaPokemonUsar original) {
        ListaEnlazadaPokemonUsar nuevaLista = new ListaEnlazadaPokemonUsar();
        // Este método necesitaría acceso a los nodos, por simplicidad
        // En un caso real se implementaría un iterador o método público
        return original; // Por ahora retornamos la original para demostración
    }
}
