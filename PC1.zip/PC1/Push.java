package PC1;

/**
 *
 * @author User
 */
public class Push implements CanalNotificacion {
    @Override
    public void enviar(Mensaje mensaje) {
        System.out.println("Enviando por Push: " + mensaje.getContenido());
    }
}