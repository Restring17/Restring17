package factory;

import enums.CondicionContrato;

public class ContratoEstable implements Contrato {
    private final int supervisionObras;
    private final int supervisionVias;
    
    public ContratoEstable(int supervisionObras, int supervisionVias) {
        this.supervisionObras = supervisionObras;
        this.supervisionVias = supervisionVias;
    }
    
    @Override
    public CondicionContrato obtenerCondicion() {
        return CondicionContrato.ESTABLE;
    }
    
    @Override
    public int getSupervisionObras() {
        return supervisionObras;
    }
    
    @Override
    public int getSupervisionVias() {
        return supervisionVias;
    }
}
