package Ejercicio5_ListaCircularPokemon;

/**
 * Lista circular de Pokemon con algoritmos de ordenamiento
 * @author User
 */
public class ListaCircularPokemonUsar implements ListaCircularPokemon {
    private NodoCircularPokemon cabeza;
    private NodoCircularPokemon actual;
    private int tamanio;

    public ListaCircularPokemonUsar() {
        this.cabeza = null;
        this.actual = null;
        this.tamanio = 0;
    }

    @Override
    public void agregar(Pokemon pokemon) {
        NodoCircularPokemon nuevo = new NodoCircularPokemon(pokemon);
        if (cabeza == null) {
            cabeza = nuevo;
            nuevo.setSiguiente(cabeza);
            actual = cabeza;
        } else {
            NodoCircularPokemon temp = cabeza;
            while (temp.getSiguiente() != cabeza) {
                temp = temp.getSiguiente();
            }
            temp.setSiguiente(nuevo);
            nuevo.setSiguiente(cabeza);
        }
        tamanio++;
    }

    @Override
    public void agregarInicio(Pokemon pokemon) {
        NodoCircularPokemon nuevo = new NodoCircularPokemon(pokemon);
        if (cabeza == null) {
            cabeza = nuevo;
            nuevo.setSiguiente(cabeza);
            actual = cabeza;
        } else {
            NodoCircularPokemon temp = cabeza;
            while (temp.getSiguiente() != cabeza) {
                temp = temp.getSiguiente();
            }
            nuevo.setSiguiente(cabeza);
            temp.setSiguiente(nuevo);
            cabeza = nuevo;
            actual = cabeza;
        }
        tamanio++;
    }

    @Override
    public boolean eliminar(String nombre) {
        if (cabeza == null) return false;

        if (cabeza.getSiguiente() == cabeza && cabeza.getPokemon().getNombre().equals(nombre)) {
            cabeza = null;
            actual = null;
            tamanio--;
            return true;
        }

        if (cabeza.getPokemon().getNombre().equals(nombre)) {
            NodoCircularPokemon temp = cabeza;
            while (temp.getSiguiente() != cabeza) {
                temp = temp.getSiguiente();
            }
            temp.setSiguiente(cabeza.getSiguiente());
            cabeza = cabeza.getSiguiente();
            actual = cabeza;
            tamanio--;
            return true;
        }

        NodoCircularPokemon temp = cabeza;
        do {
            if (temp.getSiguiente().getPokemon().getNombre().equals(nombre)) {
                temp.setSiguiente(temp.getSiguiente().getSiguiente());
                if (actual.getPokemon().getNombre().equals(nombre)) {
                    actual = temp.getSiguiente();
                }
                tamanio--;
                return true;
            }
            temp = temp.getSiguiente();
        } while (temp != cabeza);

        return false;
    }

    @Override
    public boolean contiene(String nombre) {
        if (cabeza == null) return false;
        NodoCircularPokemon temp = cabeza;
        do {
            if (temp.getPokemon().getNombre().equals(nombre)) return true;
            temp = temp.getSiguiente();
        } while (temp != cabeza);
        return false;
    }

    @Override
    public void imprimir() {
        if (cabeza == null) {
            System.out.println("Lista vacía");
            return;
        }
        NodoCircularPokemon temp = cabeza;
        System.out.print("Circular Pokemon: ");
        do {
            System.out.print(temp.getPokemon() + " -> ");
            temp = temp.getSiguiente();
        } while (temp != cabeza);
        System.out.println("(cabeza)");
    }

    @Override
    public void imprimirCompleta() {
        if (cabeza == null) {
            System.out.println("Lista vacía");
            return;
        }
        NodoCircularPokemon temp = cabeza;
        System.out.println("Vuelta completa:");
        do {
            System.out.println("  - " + temp.getPokemon());
            temp = temp.getSiguiente();
        } while (temp != cabeza);
    }

    @Override
    public void avanzar() {
        if (actual != null) {
            actual = actual.getSiguiente();
        }
    }

    @Override
    public Pokemon obtenerActual() {
        if (actual != null) {
            return actual.getPokemon();
        }
        throw new IllegalStateException("Lista vacía");
    }

    @Override
    public boolean estaVacia() {
        return cabeza == null;
    }

    @Override
    public int tamanio() {
        return tamanio;
    }

    // ==================== ORDENAMIENTO POR PODER ====================

    @Override
    public void OrdenarBubbleSortPorPoder() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        
        boolean huboIntercambio;
        do {
            huboIntercambio = false;
            NodoCircularPokemon temp = cabeza;
            do {
                NodoCircularPokemon siguiente = temp.getSiguiente();
                if (temp.getPokemon().getPoder() > siguiente.getPokemon().getPoder()) {
                    Pokemon pokemonTemp = temp.getPokemon();
                    temp.setPokemon(siguiente.getPokemon());
                    siguiente.setPokemon(pokemonTemp);
                    huboIntercambio = true;
                }
                temp = temp.getSiguiente();
            } while (temp.getSiguiente() != cabeza);
        } while (huboIntercambio);
    }

    @Override
    public void OrdenarSelectionSortPorPoder() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        
        NodoCircularPokemon i = cabeza;
        do {
            NodoCircularPokemon minNodo = i;
            NodoCircularPokemon j = i.getSiguiente();
            
            while (j != cabeza) {
                if (j.getPokemon().getPoder() < minNodo.getPokemon().getPoder()) {
                    minNodo = j;
                }
                j = j.getSiguiente();
            }
            
            if (minNodo != i) {
                Pokemon temp = i.getPokemon();
                i.setPokemon(minNodo.getPokemon());
                minNodo.setPokemon(temp);
            }
            
            i = i.getSiguiente();
        } while (i.getSiguiente() != cabeza);
    }

    @Override
    public void OrdenarInsertionSortPorPoder() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        romperYOrdenarPorPoder(true);
    }

    @Override
    public void OrdenarMergeSortPorPoder() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        romperYOrdenarPorPoder(false);
    }

    @Override
    public void OrdenarQuickSortPorPoder() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        
        NodoCircularPokemon ultimo = cabeza;
        while (ultimo.getSiguiente() != cabeza) {
            ultimo = ultimo.getSiguiente();
        }
        ultimo.setSiguiente(null);
        
        cabeza = quickSortPoder(cabeza, ultimo);
        
        ultimo = cabeza;
        while (ultimo.getSiguiente() != null) {
            ultimo = ultimo.getSiguiente();
        }
        ultimo.setSiguiente(cabeza);
        actual = cabeza;
    }

    // ==================== ORDENAMIENTO POR NOMBRE ====================

    @Override
    public void OrdenarBubbleSortPorNombre() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        
        boolean huboIntercambio;
        do {
            huboIntercambio = false;
            NodoCircularPokemon temp = cabeza;
            do {
                NodoCircularPokemon siguiente = temp.getSiguiente();
                if (temp.getPokemon().getNombre().compareTo(siguiente.getPokemon().getNombre()) > 0) {
                    Pokemon pokemonTemp = temp.getPokemon();
                    temp.setPokemon(siguiente.getPokemon());
                    siguiente.setPokemon(pokemonTemp);
                    huboIntercambio = true;
                }
                temp = temp.getSiguiente();
            } while (temp.getSiguiente() != cabeza);
        } while (huboIntercambio);
    }

    @Override
    public void OrdenarSelectionSortPorNombre() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        
        NodoCircularPokemon i = cabeza;
        do {
            NodoCircularPokemon minNodo = i;
            NodoCircularPokemon j = i.getSiguiente();
            
            while (j != cabeza) {
                if (j.getPokemon().getNombre().compareTo(minNodo.getPokemon().getNombre()) < 0) {
                    minNodo = j;
                }
                j = j.getSiguiente();
            }
            
            if (minNodo != i) {
                Pokemon temp = i.getPokemon();
                i.setPokemon(minNodo.getPokemon());
                minNodo.setPokemon(temp);
            }
            
            i = i.getSiguiente();
        } while (i.getSiguiente() != cabeza);
    }

    @Override
    public void OrdenarInsertionSortPorNombre() {
        // Implementación similar a poder pero comparando nombres
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        romperYOrdenarPorNombre(true);
    }

    @Override
    public void OrdenarMergeSortPorNombre() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        romperYOrdenarPorNombre(false);
    }

    @Override
    public void OrdenarQuickSortPorNombre() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        
        NodoCircularPokemon ultimo = cabeza;
        while (ultimo.getSiguiente() != cabeza) {
            ultimo = ultimo.getSiguiente();
        }
        ultimo.setSiguiente(null);
        
        cabeza = quickSortNombre(cabeza, ultimo);
        
        ultimo = cabeza;
        while (ultimo.getSiguiente() != null) {
            ultimo = ultimo.getSiguiente();
        }
        ultimo.setSiguiente(cabeza);
        actual = cabeza;
    }

    // ==================== MÉTODOS AUXILIARES ====================

    private void romperYOrdenarPorPoder(boolean insertion) {
        NodoCircularPokemon ultimo = cabeza;
        while (ultimo.getSiguiente() != cabeza) {
            ultimo = ultimo.getSiguiente();
        }
        ultimo.setSiguiente(null);
        
        if (insertion) {
            cabeza = insertionSortPoder(cabeza);
        } else {
            cabeza = mergeSortPoder(cabeza);
        }
        
        ultimo = cabeza;
        while (ultimo.getSiguiente() != null) {
            ultimo = ultimo.getSiguiente();
        }
        ultimo.setSiguiente(cabeza);
        actual = cabeza;
    }

    private void romperYOrdenarPorNombre(boolean insertion) {
        NodoCircularPokemon ultimo = cabeza;
        while (ultimo.getSiguiente() != cabeza) {
            ultimo = ultimo.getSiguiente();
        }
        ultimo.setSiguiente(null);
        
        if (insertion) {
            cabeza = insertionSortNombre(cabeza);
        } else {
            cabeza = mergeSortNombre(cabeza);
        }
        
        ultimo = cabeza;
        while (ultimo.getSiguiente() != null) {
            ultimo = ultimo.getSiguiente();
        }
        ultimo.setSiguiente(cabeza);
        actual = cabeza;
    }

    private NodoCircularPokemon insertionSortPoder(NodoCircularPokemon inicio) {
        NodoCircularPokemon ordenada = null;
        NodoCircularPokemon current = inicio;
        
        while (current != null) {
            NodoCircularPokemon siguiente = current.getSiguiente();
            
            if (ordenada == null || ordenada.getPokemon().getPoder() >= current.getPokemon().getPoder()) {
                current.setSiguiente(ordenada);
                ordenada = current;
            } else {
                NodoCircularPokemon temp = ordenada;
                while (temp.getSiguiente() != null && temp.getSiguiente().getPokemon().getPoder() < current.getPokemon().getPoder()) {
                    temp = temp.getSiguiente();
                }
                current.setSiguiente(temp.getSiguiente());
                temp.setSiguiente(current);
            }
            
            current = siguiente;
        }
        
        return ordenada;
    }

    private NodoCircularPokemon insertionSortNombre(NodoCircularPokemon inicio) {
        NodoCircularPokemon ordenada = null;
        NodoCircularPokemon current = inicio;
        
        while (current != null) {
            NodoCircularPokemon siguiente = current.getSiguiente();
            
            if (ordenada == null || ordenada.getPokemon().getNombre().compareTo(current.getPokemon().getNombre()) >= 0) {
                current.setSiguiente(ordenada);
                ordenada = current;
            } else {
                NodoCircularPokemon temp = ordenada;
                while (temp.getSiguiente() != null && temp.getSiguiente().getPokemon().getNombre().compareTo(current.getPokemon().getNombre()) < 0) {
                    temp = temp.getSiguiente();
                }
                current.setSiguiente(temp.getSiguiente());
                temp.setSiguiente(current);
            }
            
            current = siguiente;
        }
        
        return ordenada;
    }

    private NodoCircularPokemon mergeSortPoder(NodoCircularPokemon inicio) {
        if (inicio == null || inicio.getSiguiente() == null) return inicio;
        
        NodoCircularPokemon medio = obtenerMitad(inicio);
        NodoCircularPokemon segundaMitad = medio.getSiguiente();
        medio.setSiguiente(null);
        
        return fusionarPoder(mergeSortPoder(inicio), mergeSortPoder(segundaMitad));
    }

    private NodoCircularPokemon mergeSortNombre(NodoCircularPokemon inicio) {
        if (inicio == null || inicio.getSiguiente() == null) return inicio;
        
        NodoCircularPokemon medio = obtenerMitad(inicio);
        NodoCircularPokemon segundaMitad = medio.getSiguiente();
        medio.setSiguiente(null);
        
        return fusionarNombre(mergeSortNombre(inicio), mergeSortNombre(segundaMitad));
    }

    private NodoCircularPokemon obtenerMitad(NodoCircularPokemon inicio) {
        if (inicio == null) return null;
        NodoCircularPokemon lento = inicio;
        NodoCircularPokemon rapido = inicio.getSiguiente();
        
        while (rapido != null && rapido.getSiguiente() != null) {
            lento = lento.getSiguiente();
            rapido = rapido.getSiguiente().getSiguiente();
        }
        
        return lento;
    }

    private NodoCircularPokemon fusionarPoder(NodoCircularPokemon l1, NodoCircularPokemon l2) {
        NodoCircularPokemon dummy = new NodoCircularPokemon(new Pokemon("", "", 0));
        NodoCircularPokemon current = dummy;
        
        while (l1 != null && l2 != null) {
            if (l1.getPokemon().getPoder() <= l2.getPokemon().getPoder()) {
                current.setSiguiente(l1);
                l1 = l1.getSiguiente();
            } else {
                current.setSiguiente(l2);
                l2 = l2.getSiguiente();
            }
            current = current.getSiguiente();
        }
        
        if (l1 != null) current.setSiguiente(l1);
        if (l2 != null) current.setSiguiente(l2);
        
        return dummy.getSiguiente();
    }

    private NodoCircularPokemon fusionarNombre(NodoCircularPokemon l1, NodoCircularPokemon l2) {
        NodoCircularPokemon dummy = new NodoCircularPokemon(new Pokemon("", "", 0));
        NodoCircularPokemon current = dummy;
        
        while (l1 != null && l2 != null) {
            if (l1.getPokemon().getNombre().compareTo(l2.getPokemon().getNombre()) <= 0) {
                current.setSiguiente(l1);
                l1 = l1.getSiguiente();
            } else {
                current.setSiguiente(l2);
                l2 = l2.getSiguiente();
            }
            current = current.getSiguiente();
        }
        
        if (l1 != null) current.setSiguiente(l1);
        if (l2 != null) current.setSiguiente(l2);
        
        return dummy.getSiguiente();
    }

    private NodoCircularPokemon quickSortPoder(NodoCircularPokemon inicio, NodoCircularPokemon fin) {
        if (inicio == null || inicio == fin) return inicio;
        
        NodoCircularPokemon[] resultado = particionarPoder(inicio, fin);
        NodoCircularPokemon pivote = resultado[0];
        NodoCircularPokemon nuevoInicio = resultado[1];
        
        if (nuevoInicio != pivote) {
            NodoCircularPokemon temp = nuevoInicio;
            while (temp.getSiguiente() != pivote) temp = temp.getSiguiente();
            temp.setSiguiente(null);
            nuevoInicio = quickSortPoder(nuevoInicio, temp);
            temp = obtenerUltimo(nuevoInicio);
            temp.setSiguiente(pivote);
        }
        
        pivote.setSiguiente(quickSortPoder(pivote.getSiguiente(), fin));
        return nuevoInicio;
    }

    private NodoCircularPokemon quickSortNombre(NodoCircularPokemon inicio, NodoCircularPokemon fin) {
        if (inicio == null || inicio == fin) return inicio;
        
        NodoCircularPokemon[] resultado = particionarNombre(inicio, fin);
        NodoCircularPokemon pivote = resultado[0];
        NodoCircularPokemon nuevoInicio = resultado[1];
        
        if (nuevoInicio != pivote) {
            NodoCircularPokemon temp = nuevoInicio;
            while (temp.getSiguiente() != pivote) temp = temp.getSiguiente();
            temp.setSiguiente(null);
            nuevoInicio = quickSortNombre(nuevoInicio, temp);
            temp = obtenerUltimo(nuevoInicio);
            temp.setSiguiente(pivote);
        }
        
        pivote.setSiguiente(quickSortNombre(pivote.getSiguiente(), fin));
        return nuevoInicio;
    }

    private NodoCircularPokemon[] particionarPoder(NodoCircularPokemon inicio, NodoCircularPokemon fin) {
        NodoCircularPokemon pivote = fin;
        NodoCircularPokemon anterior = null;
        NodoCircularPokemon current = inicio;
        NodoCircularPokemon cola = pivote;
        
        while (current != pivote) {
            if (current.getPokemon().getPoder() < pivote.getPokemon().getPoder()) {
                if (anterior == null) inicio = current;
                anterior = current;
                current = current.getSiguiente();
            } else {
                if (anterior != null) anterior.setSiguiente(current.getSiguiente());
                NodoCircularPokemon temp = current.getSiguiente();
                current.setSiguiente(null);
                cola.setSiguiente(current);
                cola = current;
                current = temp;
            }
        }
        
        if (anterior == null) inicio = pivote;
        else anterior.setSiguiente(pivote);
        
        return new NodoCircularPokemon[]{pivote, inicio};
    }

    private NodoCircularPokemon[] particionarNombre(NodoCircularPokemon inicio, NodoCircularPokemon fin) {
        NodoCircularPokemon pivote = fin;
        NodoCircularPokemon anterior = null;
        NodoCircularPokemon current = inicio;
        NodoCircularPokemon cola = pivote;
        
        while (current != pivote) {
            if (current.getPokemon().getNombre().compareTo(pivote.getPokemon().getNombre()) < 0) {
                if (anterior == null) inicio = current;
                anterior = current;
                current = current.getSiguiente();
            } else {
                if (anterior != null) anterior.setSiguiente(current.getSiguiente());
                NodoCircularPokemon temp = current.getSiguiente();
                current.setSiguiente(null);
                cola.setSiguiente(current);
                cola = current;
                current = temp;
            }
        }
        
        if (anterior == null) inicio = pivote;
        else anterior.setSiguiente(pivote);
        
        return new NodoCircularPokemon[]{pivote, inicio};
    }

    private NodoCircularPokemon obtenerUltimo(NodoCircularPokemon nodo) {
        if (nodo == null) return null;
        while (nodo.getSiguiente() != null) nodo = nodo.getSiguiente();
        return nodo;
    }
}
