package PC1;


interface CanalNotificacion {
    void enviar(Mensaje mensaje);
}
