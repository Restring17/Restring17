package PC2_Preparacion.controlador;

import PC2_Preparacion.modelo.*;

/**
 * ✅ SOLUCIONES COMPLETAS - LISTA DOBLEMENTE ENLAZADA DE ESTUDIANTES
 * 
 * Este archivo contiene las 9 preguntas resueltas para listas dobles.
 * Úsalo como guía si te atascas, pero intenta resolver primero en ListaDobleController.java
 */
public class ListaDobleController_SOLUCIONES {
    private NodoDoble cabeza;
    private NodoDoble cola;
    private int tamano;

    public ListaDobleController_SOLUCIONES() {
        this.cabeza = null;
        this.cola = null;
        this.tamano = 0;
    }

    // ==================== OPERACIONES BÁSICAS ====================
    
    public void agregar(Estudiante estudiante) {
        NodoDoble nuevo = new NodoDoble(estudiante);
        
        if (cabeza == null) {
            cabeza = nuevo;
            cola = nuevo;
        } else {
            cola.setSiguiente(nuevo);
            nuevo.setAnterior(cola);
            cola = nuevo;
        }
        tamano++;
    }

    public void imprimirAdelante() {
        System.out.println("\n=== LISTA DOBLE (ADELANTE) ===");
        NodoDoble actual = cabeza;
        while (actual != null) {
            System.out.println(actual.getDato());
            actual = actual.getSiguiente();
        }
        System.out.println("Total: " + tamano + " estudiantes\n");
    }

    public void imprimirAtras() {
        System.out.println("\n=== LISTA DOBLE (ATRÁS) ===");
        NodoDoble actual = cola;
        while (actual != null) {
            System.out.println(actual.getDato());
            actual = actual.getAnterior();
        }
        System.out.println("Total: " + tamano + " estudiantes\n");
    }

    public Estudiante[] toArray() {
        Estudiante[] array = new Estudiante[tamano];
        NodoDoble actual = cabeza;
        int i = 0;
        
        while (actual != null) {
            array[i++] = actual.getDato();
            actual = actual.getSiguiente();
        }
        
        return array;
    }

    private void fromArray(Estudiante[] array) {
        cabeza = null;
        cola = null;
        tamano = 0;
        for (Estudiante e : array) {
            agregar(e);
        }
    }

    // ==================== PREGUNTA 7A: SELECTION SORT POR CICLO ====================
    
    /**
     * ✅ SOLUCIÓN 7A: Ordenar por ciclo (Selection Sort) - Ascendente
     */
    public void ordenarPorCicloSelectionSort() {
        if (tamano <= 1) return;
        
        // Convertir a array
        Estudiante[] array = toArray();
        
        // Selection Sort por ciclo (menor a mayor)
        for (int i = 0; i < array.length - 1; i++) {
            int indiceMinimo = i;
            
            // Buscar el mínimo en el resto del array
            for (int j = i + 1; j < array.length; j++) {
                if (array[j].getCiclo() < array[indiceMinimo].getCiclo()) {
                    indiceMinimo = j;
                }
            }
            
            // Intercambiar si es necesario
            if (indiceMinimo != i) {
                Estudiante temp = array[i];
                array[i] = array[indiceMinimo];
                array[indiceMinimo] = temp;
            }
        }
        
        // Reconstruir lista doble
        fromArray(array);
    }

    // ==================== PREGUNTA 7B: MERGE SORT POR CÓDIGO ====================
    
    /**
     * ✅ SOLUCIÓN 7B: Ordenar por código (Merge Sort) - Descendente
     */
    public void ordenarPorCodigoMergeSort() {
        if (tamano <= 1) return;
        
        Estudiante[] array = toArray();
        mergeSortRecursivo(array, 0, array.length - 1);
        fromArray(array);
    }

    private void mergeSortRecursivo(Estudiante[] array, int inicio, int fin) {
        if (inicio < fin) {
            int medio = inicio + (fin - inicio) / 2;
            
            // Dividir
            mergeSortRecursivo(array, inicio, medio);
            mergeSortRecursivo(array, medio + 1, fin);
            
            // Conquistar
            merge(array, inicio, medio, fin);
        }
    }

    private void merge(Estudiante[] array, int inicio, int medio, int fin) {
        // Crear arrays temporales
        int n1 = medio - inicio + 1;
        int n2 = fin - medio;
        
        Estudiante[] izquierda = new Estudiante[n1];
        Estudiante[] derecha = new Estudiante[n2];
        
        // Copiar datos
        for (int i = 0; i < n1; i++) {
            izquierda[i] = array[inicio + i];
        }
        for (int j = 0; j < n2; j++) {
            derecha[j] = array[medio + 1 + j];
        }
        
        // Mezclar en orden DESCENDENTE
        int i = 0, j = 0, k = inicio;
        
        while (i < n1 && j < n2) {
            // DESCENDENTE: mayor primero
            if (izquierda[i].getCodigo().compareToIgnoreCase(derecha[j].getCodigo()) >= 0) {
                array[k] = izquierda[i];
                i++;
            } else {
                array[k] = derecha[j];
                j++;
            }
            k++;
        }
        
        // Copiar elementos restantes
        while (i < n1) {
            array[k] = izquierda[i];
            i++;
            k++;
        }
        
        while (j < n2) {
            array[k] = derecha[j];
            j++;
            k++;
        }
    }

    // ==================== PREGUNTA 8A: BÚSQUEDA BIDIRECCIONAL ====================
    
    /**
     * ✅ SOLUCIÓN 8A: Búsqueda bidireccional por promedio
     */
    public Estudiante[] buscarPorPromedioBidireccional(double promedioBuscado, double promedioMedio) {
        if (cabeza == null) return new Estudiante[0];
        
        // Decidir dirección de búsqueda
        boolean buscarDesdeInicio = promedioBuscado >= promedioMedio;
        
        // PASADA 1: Contar
        int contador = 0;
        
        if (buscarDesdeInicio) {
            // Buscar desde cabeza
            NodoDoble actual = cabeza;
            while (actual != null) {
                if (Math.abs(actual.getDato().getPromedio() - promedioBuscado) < 0.01) {
                    contador++;
                }
                actual = actual.getSiguiente();
            }
        } else {
            // Buscar desde cola
            NodoDoble actual = cola;
            while (actual != null) {
                if (Math.abs(actual.getDato().getPromedio() - promedioBuscado) < 0.01) {
                    contador++;
                }
                actual = actual.getAnterior();
            }
        }
        
        // Crear array
        Estudiante[] resultado = new Estudiante[contador];
        
        // PASADA 2: Llenar
        int indice = 0;
        
        if (buscarDesdeInicio) {
            NodoDoble actual = cabeza;
            while (actual != null) {
                if (Math.abs(actual.getDato().getPromedio() - promedioBuscado) < 0.01) {
                    resultado[indice++] = actual.getDato();
                }
                actual = actual.getSiguiente();
            }
        } else {
            NodoDoble actual = cola;
            while (actual != null) {
                if (Math.abs(actual.getDato().getPromedio() - promedioBuscado) < 0.01) {
                    resultado[indice++] = actual.getDato();
                }
                actual = actual.getAnterior();
            }
        }
        
        return resultado;
    }

    // ==================== PREGUNTA 8B: BUSCAR DESDE ATRÁS ====================
    
    /**
     * ✅ SOLUCIÓN 8B: Buscar estudiantes por ciclo (desde atrás)
     */
    public Estudiante[] buscarPorCicloDesdeAtras(int ciclo) {
        if (cola == null) return new Estudiante[0];
        
        // PASADA 1: Contar desde la cola
        int contador = 0;
        NodoDoble actual = cola;
        
        while (actual != null) {
            if (actual.getDato().getCiclo() == ciclo) {
                contador++;
            }
            actual = actual.getAnterior();
        }
        
        // Crear array
        Estudiante[] resultado = new Estudiante[contador];
        
        // PASADA 2: Llenar desde la cola
        actual = cola;
        int indice = 0;
        
        while (actual != null) {
            if (actual.getDato().getCiclo() == ciclo) {
                resultado[indice++] = actual.getDato();
            }
            actual = actual.getAnterior();
        }
        
        return resultado;
    }

    // ==================== PREGUNTA 9A: INSERTAR AL INICIO ====================
    
    /**
     * ✅ SOLUCIÓN 9A: Insertar al inicio (eficientemente)
     */
    public void insertarAlInicio(Estudiante estudiante) {
        NodoDoble nuevo = new NodoDoble(estudiante);
        
        if (cabeza == null) {
            // Lista vacía
            cabeza = nuevo;
            cola = nuevo;
        } else {
            // Lista con elementos
            nuevo.setSiguiente(cabeza);
            cabeza.setAnterior(nuevo);
            cabeza = nuevo;
        }
        
        tamano++;
    }

    // ==================== PREGUNTA 9B: ELIMINAR DEL FINAL ====================
    
    /**
     * ✅ SOLUCIÓN 9B: Eliminar desde el final (eficientemente)
     */
    public Estudiante eliminarDelFinal() {
        if (cola == null) return null;
        
        Estudiante eliminado = cola.getDato();
        
        if (cabeza == cola) {
            // Único elemento
            cabeza = null;
            cola = null;
        } else {
            // Múltiples elementos
            cola = cola.getAnterior();
            cola.setSiguiente(null);
        }
        
        tamano--;
        return eliminado;
    }

    // ==================== PREGUNTA 9C: INVERTIR LISTA ====================
    
    /**
     * ✅ SOLUCIÓN 9C: Invertir la lista (in-place)
     */
    public void invertir() {
        if (cabeza == null || cabeza == cola) return;
        
        NodoDoble actual = cabeza;
        NodoDoble temp = null;
        
        // Intercambiar anterior y siguiente en cada nodo
        while (actual != null) {
            temp = actual.getAnterior();
            actual.setAnterior(actual.getSiguiente());
            actual.setSiguiente(temp);
            
            // Avanzar al siguiente (que ahora está en anterior)
            actual = actual.getAnterior();
        }
        
        // Intercambiar cabeza y cola
        temp = cabeza;
        cabeza = cola;
        cola = temp;
    }

    // ==================== PREGUNTA 9D: ELIMINAR DUPLICADOS ====================
    
    /**
     * ✅ SOLUCIÓN 9D: Eliminar duplicados por código
     */
    public int eliminarDuplicados() {
        if (cabeza == null) return 0;
        
        int eliminados = 0;
        NodoDoble actual = cabeza;
        
        while (actual != null) {
            NodoDoble comparador = actual.getSiguiente();
            
            while (comparador != null) {
                if (actual.getDato().getCodigo().equalsIgnoreCase(comparador.getDato().getCodigo())) {
                    // Duplicado encontrado, eliminar comparador
                    NodoDoble siguiente = comparador.getSiguiente();
                    
                    // Ajustar enlaces
                    if (comparador.getAnterior() != null) {
                        comparador.getAnterior().setSiguiente(comparador.getSiguiente());
                    }
                    if (comparador.getSiguiente() != null) {
                        comparador.getSiguiente().setAnterior(comparador.getAnterior());
                    }
                    
                    // Si es la cola, actualizar
                    if (comparador == cola) {
                        cola = comparador.getAnterior();
                    }
                    
                    eliminados++;
                    tamano--;
                    comparador = siguiente;
                } else {
                    comparador = comparador.getSiguiente();
                }
            }
            
            actual = actual.getSiguiente();
        }
        
        return eliminados;
    }

    // ==================== PREGUNTA 9E: OBTENER DESDE FINAL ====================
    
    /**
     * ✅ SOLUCIÓN 9E: Obtener estudiante en posición N (desde el final)
     */
    public Estudiante obtenerDesdeFinal(int posicion) {
        if (posicion < 0 || posicion >= tamano || cola == null) {
            return null;
        }
        
        NodoDoble actual = cola;
        
        // Retroceder N posiciones desde la cola
        for (int i = 0; i < posicion; i++) {
            actual = actual.getAnterior();
        }
        
        return actual.getDato();
    }

    // ==================== GETTERS ====================
    
    public int getTamano() {
        return tamano;
    }

    public NodoDoble getCabeza() {
        return cabeza;
    }

    public NodoDoble getCola() {
        return cola;
    }
}
