package Ejercicio7_ListaDobleInt;

public class ListaDobleIntUsar implements ListaDobleInt {
    private NodoDobleInt cabeza;
    private NodoDobleInt cola;
    private int tamanio;

    public ListaDobleIntUsar() {
        this.cabeza = null;
        this.cola = null;
        this.tamanio = 0;
    }

    @Override
    public void agregarInicio(int valor) {
        NodoDobleInt nuevo = new NodoDobleInt(valor);
        if (cabeza == null) {
            cabeza = cola = nuevo;
        } else {
            nuevo.setSiguiente(cabeza);
            cabeza.setAnterior(nuevo);
            cabeza = nuevo;
        }
        tamanio++;
    }

    @Override
    public void agregarFinal(int valor) {
        NodoDobleInt nuevo = new NodoDobleInt(valor);
        if (cola == null) {
            cabeza = cola = nuevo;
        } else {
            cola.setSiguiente(nuevo);
            nuevo.setAnterior(cola);
            cola = nuevo;
        }
        tamanio++;
    }

    @Override
    public boolean eliminar(int valor) {
        if (cabeza == null) return false;
        
        NodoDobleInt temp = cabeza;
        while (temp != null) {
            if (temp.getValor() == valor) {
                if (temp == cabeza) cabeza = temp.getSiguiente();
                if (temp == cola) cola = temp.getAnterior();
                if (temp.getAnterior() != null) temp.getAnterior().setSiguiente(temp.getSiguiente());
                if (temp.getSiguiente() != null) temp.getSiguiente().setAnterior(temp.getAnterior());
                tamanio--;
                return true;
            }
            temp = temp.getSiguiente();
        }
        return false;
    }

    @Override
    public boolean contiene(int valor) {
        NodoDobleInt temp = cabeza;
        while (temp != null) {
            if (temp.getValor() == valor) return true;
            temp = temp.getSiguiente();
        }
        return false;
    }

    @Override
    public void imprimirAdelante() {
        System.out.print("null <- ");
        NodoDobleInt temp = cabeza;
        while (temp != null) {
            System.out.print(temp.getValor() + " <-> ");
            temp = temp.getSiguiente();
        }
        System.out.println("null");
    }

    @Override
    public void imprimirAtras() {
        System.out.print("null -> ");
        NodoDobleInt temp = cola;
        while (temp != null) {
            System.out.print(temp.getValor() + " <-> ");
            temp = temp.getAnterior();
        }
        System.out.println("null");
    }

    @Override
    public boolean estaVacia() {
        return cabeza == null;
    }

    @Override
    public int tamanio() {
        return tamanio;
    }

    @Override
    public void OrdenarBubbleSort() {
        if (cabeza == null || cabeza.getSiguiente() == null) return;
        boolean huboIntercambio;
        do {
            huboIntercambio = false;
            NodoDobleInt temp = cabeza;
            while (temp.getSiguiente() != null) {
                if (temp.getValor() > temp.getSiguiente().getValor()) {
                    int valorTemp = temp.getValor();
                    temp.setValor(temp.getSiguiente().getValor());
                    temp.getSiguiente().setValor(valorTemp);
                    huboIntercambio = true;
                }
                temp = temp.getSiguiente();
            }
        } while (huboIntercambio);
    }

    @Override
    public void OrdenarSelectionSort() {
        if (cabeza == null || cabeza.getSiguiente() == null) return;
        NodoDobleInt i = cabeza;
        while (i != null) {
            NodoDobleInt minNodo = i;
            NodoDobleInt j = i.getSiguiente();
            while (j != null) {
                if (j.getValor() < minNodo.getValor()) minNodo = j;
                j = j.getSiguiente();
            }
            if (minNodo != i) {
                int temp = i.getValor();
                i.setValor(minNodo.getValor());
                minNodo.setValor(temp);
            }
            i = i.getSiguiente();
        }
    }

    @Override
    public void OrdenarInsertionSort() {
        if (cabeza == null || cabeza.getSiguiente() == null) return;
        NodoDobleInt ordenada = null;
        NodoDobleInt current = cabeza;
        while (current != null) {
            NodoDobleInt siguiente = current.getSiguiente();
            current.setAnterior(null);
            current.setSiguiente(null);
            ordenada = insertarOrdenado(ordenada, current);
            current = siguiente;
        }
        cabeza = ordenada;
        cola = cabeza;
        while (cola.getSiguiente() != null) cola = cola.getSiguiente();
    }

    private NodoDobleInt insertarOrdenado(NodoDobleInt ordenada, NodoDobleInt nuevo) {
        if (ordenada == null || ordenada.getValor() >= nuevo.getValor()) {
            nuevo.setSiguiente(ordenada);
            if (ordenada != null) ordenada.setAnterior(nuevo);
            return nuevo;
        }
        NodoDobleInt temp = ordenada;
        while (temp.getSiguiente() != null && temp.getSiguiente().getValor() < nuevo.getValor()) {
            temp = temp.getSiguiente();
        }
        nuevo.setSiguiente(temp.getSiguiente());
        if (temp.getSiguiente() != null) temp.getSiguiente().setAnterior(nuevo);
        temp.setSiguiente(nuevo);
        nuevo.setAnterior(temp);
        return ordenada;
    }

    @Override
    public void OrdenarMergeSort() {
        cabeza = mergeSort(cabeza);
        cola = cabeza;
        if (cola != null) while (cola.getSiguiente() != null) cola = cola.getSiguiente();
    }

    private NodoDobleInt mergeSort(NodoDobleInt inicio) {
        if (inicio == null || inicio.getSiguiente() == null) return inicio;
        NodoDobleInt medio = obtenerMitad(inicio);
        NodoDobleInt segundaMitad = medio.getSiguiente();
        medio.setSiguiente(null);
        if (segundaMitad != null) segundaMitad.setAnterior(null);
        return fusionar(mergeSort(inicio), mergeSort(segundaMitad));
    }

    private NodoDobleInt obtenerMitad(NodoDobleInt inicio) {
        if (inicio == null) return null;
        NodoDobleInt lento = inicio, rapido = inicio;
        while (rapido.getSiguiente() != null && rapido.getSiguiente().getSiguiente() != null) {
            lento = lento.getSiguiente();
            rapido = rapido.getSiguiente().getSiguiente();
        }
        return lento;
    }

    private NodoDobleInt fusionar(NodoDobleInt l1, NodoDobleInt l2) {
        if (l1 == null) return l2;
        if (l2 == null) return l1;
        if (l1.getValor() <= l2.getValor()) {
            l1.setSiguiente(fusionar(l1.getSiguiente(), l2));
            if (l1.getSiguiente() != null) l1.getSiguiente().setAnterior(l1);
            l1.setAnterior(null);
            return l1;
        } else {
            l2.setSiguiente(fusionar(l1, l2.getSiguiente()));
            if (l2.getSiguiente() != null) l2.getSiguiente().setAnterior(l2);
            l2.setAnterior(null);
            return l2;
        }
    }

    @Override
    public void OrdenarQuickSort() {
        cabeza = quickSort(cabeza);
        cola = cabeza;
        if (cola != null) while (cola.getSiguiente() != null) cola = cola.getSiguiente();
    }

    private NodoDobleInt quickSort(NodoDobleInt inicio) {
        if (inicio == null || inicio.getSiguiente() == null) return inicio;
        NodoDobleInt pivote = inicio;
        NodoDobleInt menores = null, mayores = null;
        NodoDobleInt temp = inicio.getSiguiente();
        while (temp != null) {
            NodoDobleInt siguiente = temp.getSiguiente();
            temp.setSiguiente(null);
            temp.setAnterior(null);
            if (temp.getValor() < pivote.getValor()) {
                temp.setSiguiente(menores);
                if (menores != null) menores.setAnterior(temp);
                menores = temp;
            } else {
                temp.setSiguiente(mayores);
                if (mayores != null) mayores.setAnterior(temp);
                mayores = temp;
            }
            temp = siguiente;
        }
        menores = quickSort(menores);
        mayores = quickSort(mayores);
        if (menores == null) {
            pivote.setSiguiente(mayores);
            if (mayores != null) mayores.setAnterior(pivote);
            return pivote;
        }
        NodoDobleInt fin = menores;
        while (fin.getSiguiente() != null) fin = fin.getSiguiente();
        fin.setSiguiente(pivote);
        pivote.setAnterior(fin);
        pivote.setSiguiente(mayores);
        if (mayores != null) mayores.setAnterior(pivote);
        return menores;
    }
}
