package Ejercicio7_ListaDobleInt;

/**
 * Clase de prueba para lista doblemente enlazada de enteros
 */
public class PruebaListaDobleInt {
    public static void main(String[] args) {
        ListaDobleIntUsar lista = new ListaDobleIntUsar();
        
        System.out.println("=== LISTA DOBLEMENTE ENLAZADA DE ENTEROS ===\n");
        
        // Agregar elementos
        System.out.println("Agregando elementos...");
        lista.agregarFinal(30);
        lista.agregarFinal(10);
        lista.agregarFinal(50);
        lista.agregarInicio(5);
        lista.agregarFinal(40);
        
        System.out.println("\nRecorrido hacia adelante:");
        lista.imprimirAdelante();
        
        System.out.println("\nRecorrido hacia atrás:");
        lista.imprimirAtras();
        
        // Prueba de ordenamiento
        System.out.println("\n=== ORDENAMIENTO ===");
        
        System.out.println("\nBubble Sort:");
        lista.OrdenarBubbleSort();
        lista.imprimirAdelante();
        lista.imprimirAtras();
        
        ListaDobleIntUsar lista2 = new ListaDobleIntUsar();
        lista2.agregarFinal(70); lista2.agregarFinal(20); 
        lista2.agregarFinal(90); lista2.agregarFinal(15);
        System.out.println("\nMerge Sort:");
        lista2.OrdenarMergeSort();
        lista2.imprimirAdelante();
        
        ListaDobleIntUsar lista3 = new ListaDobleIntUsar();
        lista3.agregarFinal(100); lista3.agregarFinal(25); 
        lista3.agregarFinal(75); lista3.agregarFinal(50);
        System.out.println("\nQuick Sort:");
        lista3.OrdenarQuickSort();
        lista3.imprimirAdelante();
        
        System.out.println("\n=== OPERACIONES ===");
        System.out.println("Tamaño: " + lista.tamanio());
        System.out.println("¿Contiene 30? " + lista.contiene(30));
        System.out.println("Eliminando 30: " + lista.eliminar(30));
        lista.imprimirAdelante();
    }
}
