package Ejercicio8_ListaDoblePokemon;

public class NodoDoblePokemon {
    private Pokemon pokemon;
    private NodoDoblePokemon anterior;
    private NodoDoblePokemon siguiente;

    public NodoDoblePokemon(Pokemon pokemon) {
        this.pokemon = pokemon;
        this.anterior = null;
        this.siguiente = null;
    }

    public Pokemon getPokemon() {
        return pokemon;
    }

    public void setPokemon(Pokemon pokemon) {
        this.pokemon = pokemon;
    }

    public NodoDoblePokemon getAnterior() {
        return anterior;
    }

    public void setAnterior(NodoDoblePokemon anterior) {
        this.anterior = anterior;
    }

    public NodoDoblePokemon getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoDoblePokemon siguiente) {
        this.siguiente = siguiente;
    }
}
