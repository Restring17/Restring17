package Ejercicio4_ListaCircularInt;

/**
 * Clase de prueba para lista circular de enteros
 */
public class PruebaListaCircularInt {
    public static void main(String[] args) {
        ListaCircularIntUsar lista = new ListaCircularIntUsar();
        
        System.out.println("=== LISTA CIRCULAR DE ENTEROS ===\n");
        
        // Agregar elementos
        System.out.println("Agregando elementos...");
        lista.agregar(50);
        lista.agregar(20);
        lista.agregar(80);
        lista.agregar(10);
        lista.agregarInicio(100);
        
        System.out.println("Lista original:");
        lista.imprimir();
        
        System.out.println("\nVuelta completa a la lista circular:");
        lista.imprimirCompleta();
        
        // Navegación circular
        System.out.println("\n=== NAVEGACIÓN CIRCULAR ===");
        System.out.println("Actual: " + lista.obtenerActual());
        lista.avanzar();
        System.out.println("Después de avanzar: " + lista.obtenerActual());
        lista.avanzar();
        lista.avanzar();
        System.out.println("Después de 2 avances más: " + lista.obtenerActual());
        
        // Prueba de ordenamiento
        System.out.println("\n=== ORDENAMIENTO ===");
        
        ListaCircularIntUsar listaBubble = new ListaCircularIntUsar();
        listaBubble.agregar(50); listaBubble.agregar(20); 
        listaBubble.agregar(80); listaBubble.agregar(10);
        System.out.println("\nBubble Sort:");
        listaBubble.OrdenarBubbleSort();
        listaBubble.imprimir();
        
        ListaCircularIntUsar listaMerge = new ListaCircularIntUsar();
        listaMerge.agregar(50); listaMerge.agregar(20); 
        listaMerge.agregar(80); listaMerge.agregar(10);
        System.out.println("\nMerge Sort:");
        listaMerge.OrdenarMergeSort();
        listaMerge.imprimir();
        
        System.out.println("\nTamaño de la lista: " + lista.tamanio());
        System.out.println("¿Contiene 80? " + lista.contiene(80));
        System.out.println("¿Contiene 999? " + lista.contiene(999));
    }
}
