package Ejercicio1;

/**
 *
 * @author User
 */
interface ListaEnlazada {
    void agregarInicio(int valor);
    void agregarFinal(int valor);
    boolean eliminar(int valor);
    boolean contiene(int valor);
    boolean contieneOrdenado(int valor);
    void imprimir();
    
    //Ordenamiento
    void OrdenarBubblesort();
    void OrdenarSelectionsort();
    void OrdenarMergesort();
    void OrdenarQuicksort();
    void OrdenarInsertionsort();
}
