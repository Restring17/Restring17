package PC2_Preparacion.ejemplos;

import PC2_Preparacion.modelo.*;

/**
 * EJEMPLO RESUELTO: BÚSQUEDA CON RETORNO DE ARRAY
 * 
 * Este ejemplo muestra cómo buscar en una lista enlazada recorriendo nodo por nodo
 * y retornar las coincidencias en un array, SIN convertir la lista completa a array.
 * 
 * CASO TÍPICO DE EXAMEN:
 * "Implemente un método que busque todos los estudiantes cuyo promedio sea mayor o igual
 * a un valor dado, recorriendo la lista enlazada y retornando un arreglo con los resultados."
 */
public class BusquedaConArray {
    
    /**
     * PREGUNTA TIPO EXAMEN RESUELTA:
     * Buscar todos los estudiantes con promedio >= promedioMinimo
     * 
     * RESTRICCIONES:
     * - Recorrer la lista nodo por nodo (NO usar toArray())
     * - Retornar un arreglo Estudiante[] con las coincidencias
     * - NO modificar la lista original
     * 
     * ESTRATEGIA DE SOLUCIÓN:
     * 1. Primera pasada: contar cuántos nodos cumplen la condición
     * 2. Crear array con el tamaño exacto
     * 3. Segunda pasada: llenar el array con las coincidencias
     */
    public static Estudiante[] buscarPorPromedioMinimo(NodoSimple cabeza, double promedioMinimo) {
        // ============ PASO 1: CONTAR COINCIDENCIAS ============
        int contador = 0;
        NodoSimple actual = cabeza;
        
        while (actual != null) {
            if (actual.getDato().getPromedio() >= promedioMinimo) {
                contador++;
            }
            actual = actual.getSiguiente();
        }
        
        // ============ PASO 2: CREAR ARRAY DEL TAMAÑO CORRECTO ============
        Estudiante[] resultado = new Estudiante[contador];
        
        // ============ PASO 3: LLENAR EL ARRAY ============
        actual = cabeza;  // Reiniciar al inicio de la lista
        int indice = 0;
        
        while (actual != null) {
            if (actual.getDato().getPromedio() >= promedioMinimo) {
                resultado[indice] = actual.getDato();
                indice++;
            }
            actual = actual.getSiguiente();
        }
        
        return resultado;
    }
    
    /**
     * VARIANTE 1: Buscar por ciclo (comparación exacta)
     */
    public static Estudiante[] buscarPorCiclo(NodoSimple cabeza, int ciclo) {
        // Primera pasada: contar
        int contador = 0;
        NodoSimple actual = cabeza;
        
        while (actual != null) {
            if (actual.getDato().getCiclo() == ciclo) {
                contador++;
            }
            actual = actual.getSiguiente();
        }
        
        // Segunda pasada: llenar array
        Estudiante[] resultado = new Estudiante[contador];
        actual = cabeza;
        int indice = 0;
        
        while (actual != null) {
            if (actual.getDato().getCiclo() == ciclo) {
                resultado[indice++] = actual.getDato();
            }
            actual = actual.getSiguiente();
        }
        
        return resultado;
    }
    
    /**
     * VARIANTE 2: Buscar por nombre (parcial, case-insensitive)
     * ⚠️ LECCIÓN DEL PC1: Usar contains() no equals()
     */
    public static Estudiante[] buscarPorNombreParcial(NodoSimple cabeza, String textoBuscado) {
        // Primera pasada: contar
        int contador = 0;
        NodoSimple actual = cabeza;
        
        while (actual != null) {
            String nombreLower = actual.getDato().getNombre().toLowerCase();
            String textoLower = textoBuscado.toLowerCase();
            
            if (nombreLower.contains(textoLower)) {
                contador++;
            }
            actual = actual.getSiguiente();
        }
        
        // Segunda pasada: llenar array
        Estudiante[] resultado = new Estudiante[contador];
        actual = cabeza;
        int indice = 0;
        
        while (actual != null) {
            String nombreLower = actual.getDato().getNombre().toLowerCase();
            String textoLower = textoBuscado.toLowerCase();
            
            if (nombreLower.contains(textoLower)) {
                resultado[indice++] = actual.getDato();
            }
            actual = actual.getSiguiente();
        }
        
        return resultado;
    }
    
    /**
     * VARIANTE 3: Buscar en rango (promedio entre min y max)
     */
    public static Estudiante[] buscarEnRangoPromedio(NodoSimple cabeza, double min, double max) {
        // Primera pasada: contar
        int contador = 0;
        NodoSimple actual = cabeza;
        
        while (actual != null) {
            double promedio = actual.getDato().getPromedio();
            if (promedio >= min && promedio <= max) {
                contador++;
            }
            actual = actual.getSiguiente();
        }
        
        // Segunda pasada: llenar array
        Estudiante[] resultado = new Estudiante[contador];
        actual = cabeza;
        int indice = 0;
        
        while (actual != null) {
            double promedio = actual.getDato().getPromedio();
            if (promedio >= min && promedio <= max) {
                resultado[indice++] = actual.getDato();
            }
            actual = actual.getSiguiente();
        }
        
        return resultado;
    }
    
    /**
     * VARIANTE 4: Buscar estudiantes con código que empiece con prefijo
     */
    public static Estudiante[] buscarPorCodigoPrefijo(NodoSimple cabeza, String prefijo) {
        // Primera pasada: contar
        int contador = 0;
        NodoSimple actual = cabeza;
        
        while (actual != null) {
            if (actual.getDato().getCodigo().startsWith(prefijo)) {
                contador++;
            }
            actual = actual.getSiguiente();
        }
        
        // Segunda pasada: llenar array
        Estudiante[] resultado = new Estudiante[contador];
        actual = cabeza;
        int indice = 0;
        
        while (actual != null) {
            if (actual.getDato().getCodigo().startsWith(prefijo)) {
                resultado[indice++] = actual.getDato();
            }
            actual = actual.getSiguiente();
        }
        
        return resultado;
    }
    
    // ==================== MÉTODO DE PRUEBA ====================
    
    public static void main(String[] args) {
        // Crear lista de ejemplo
        NodoSimple cabeza = crearListaEjemplo();
        
        System.out.println("╔════════════════════════════════════════════════════════════╗");
        System.out.println("║  EJEMPLO RESUELTO: BÚSQUEDA CON RETORNO DE ARRAY          ║");
        System.out.println("╚════════════════════════════════════════════════════════════╝\n");
        
        // Imprimir lista completa
        System.out.println("📋 LISTA COMPLETA:");
        imprimirLista(cabeza);
        
        // PRUEBA 1: Buscar por promedio mínimo
        System.out.println("\n🔍 PRUEBA 1: Estudiantes con promedio >= 16.0");
        Estudiante[] resultado1 = buscarPorPromedioMinimo(cabeza, 16.0);
        imprimirArray(resultado1);
        
        // PRUEBA 2: Buscar por ciclo
        System.out.println("\n🔍 PRUEBA 2: Estudiantes del ciclo 5");
        Estudiante[] resultado2 = buscarPorCiclo(cabeza, 5);
        imprimirArray(resultado2);
        
        // PRUEBA 3: Buscar por nombre parcial
        System.out.println("\n🔍 PRUEBA 3: Estudiantes con 'ar' en el nombre");
        Estudiante[] resultado3 = buscarPorNombreParcial(cabeza, "ar");
        imprimirArray(resultado3);
        
        // PRUEBA 4: Buscar en rango
        System.out.println("\n🔍 PRUEBA 4: Estudiantes con promedio entre 14.0 y 17.0");
        Estudiante[] resultado4 = buscarEnRangoPromedio(cabeza, 14.0, 17.0);
        imprimirArray(resultado4);
        
        // PRUEBA 5: Buscar por prefijo de código
        System.out.println("\n🔍 PRUEBA 5: Estudiantes con código que empieza con 'U2020'");
        Estudiante[] resultado5 = buscarPorCodigoPrefijo(cabeza, "U2020");
        imprimirArray(resultado5);
        
        System.out.println("\n✅ TODAS LAS PRUEBAS COMPLETADAS\n");
    }
    
    // ==================== MÉTODOS AUXILIARES ====================
    
    private static NodoSimple crearListaEjemplo() {
        NodoSimple cabeza = new NodoSimple(new Estudiante("U20201001", "Juan Pérez", 16.5, 5));
        NodoSimple actual = cabeza;
        
        actual.setSiguiente(new NodoSimple(new Estudiante("U20201002", "Ana García", 18.0, 5)));
        actual = actual.getSiguiente();
        
        actual.setSiguiente(new NodoSimple(new Estudiante("U20201003", "Carlos López", 14.2, 4)));
        actual = actual.getSiguiente();
        
        actual.setSiguiente(new NodoSimple(new Estudiante("U20201004", "María Rodríguez", 17.8, 6)));
        actual = actual.getSiguiente();
        
        actual.setSiguiente(new NodoSimple(new Estudiante("U20201005", "Luis Martínez", 13.5, 4)));
        actual = actual.getSiguiente();
        
        actual.setSiguiente(new NodoSimple(new Estudiante("U20201006", "Sofía Hernández", 16.5, 5)));
        
        return cabeza;
    }
    
    private static void imprimirLista(NodoSimple cabeza) {
        NodoSimple actual = cabeza;
        int contador = 1;
        
        while (actual != null) {
            System.out.println("   " + contador + ". " + actual.getDato());
            actual = actual.getSiguiente();
            contador++;
        }
    }
    
    private static void imprimirArray(Estudiante[] array) {
        if (array.length == 0) {
            System.out.println("   ❌ No se encontraron coincidencias");
            return;
        }
        
        System.out.println("   ✅ Se encontraron " + array.length + " coincidencia(s):");
        for (int i = 0; i < array.length; i++) {
            System.out.println("      " + (i + 1) + ". " + array[i]);
        }
    }
}
