package Ejercicio1;

/**
 *
 * @author User
 */
public class ListaEnlazadaUsar implements ListaEnlazada{
    private Nodo cabeza;

    public ListaEnlazadaUsar() {
        cabeza=null;
    }

    @Override
    public void agregarInicio(int valor) {
        Nodo nuevo=new Nodo(valor);
        nuevo.siguiente=cabeza;
        cabeza=nuevo;
    }

    @Override
    public void agregarFinal(int valor) {
        Nodo nuevo=new Nodo(valor);
        if (cabeza==null) {
            cabeza=nuevo;
        }else{
            Nodo actual=cabeza;
            while(actual.siguiente!=null){
                actual=actual.siguiente;
            }
            actual.siguiente=nuevo;
        }
    }

    @Override
    public boolean eliminar(int valor) {
        if (cabeza==null) return false;        
        if (cabeza.valor==valor) {
            cabeza=cabeza.siguiente;
            return true;
        }
        Nodo actual=cabeza;
        while (actual.siguiente!=null && actual.siguiente.valor!=valor) {            
            actual=actual.siguiente;
        }
        if(actual.siguiente==null)return false;
        actual.siguiente=actual.siguiente.siguiente;
        return true;
    }

    @Override
    public boolean contiene(int valor) {
        Nodo actual=cabeza;
        while (actual!=null) {                
            if (actual.valor==valor)return true;
            actual=actual.siguiente;
        }
        return false;
    }

    @Override
    public boolean contieneOrdenado(int valor) {
        Nodo actual=cabeza;
        while (actual!=null) {                
            if (actual.valor==valor){
                return true;
            }else if (actual.valor>valor) {
                return false;
            }
            actual=actual.siguiente;
        }
        return false;        
    }

    @Override
    public void imprimir() {
        Nodo actual=cabeza;
        while (actual!=null) {            
            System.out.print("- "+actual.valor);
            actual=actual.siguiente;
        }
        System.out.println(" - null");
    }

    @Override
    public void OrdenarBubblesort() {
        if(cabeza==null || cabeza.siguiente==null) return;
        boolean huboIntercambio;
        do {            
            Nodo actual=cabeza;
            Nodo siguiente=cabeza.siguiente;
            huboIntercambio=false;
            while (siguiente!=null) {                
                if (actual.getValor()>siguiente.getValor()) {
                    int temp=actual.getValor();
                    actual.setValor(siguiente.getValor());
                    siguiente.setValor(temp);
                    huboIntercambio=true;
                }
                actual=siguiente;
                siguiente=siguiente.getSiguiente();
            }
        } while (huboIntercambio);
    }

    @Override
    public void OrdenarSelectionsort() {
        if (cabeza == null || cabeza.siguiente == null) return;
        
        Nodo actual = cabeza;
        
        while (actual != null) {
            // Encontrar el nodo con el valor mínimo en el resto de la lista
            Nodo minNodo = actual;
            Nodo temp = actual.siguiente;
            
            while (temp != null) {
                if (temp.getValor() < minNodo.getValor()) {
                    minNodo = temp;
                }
                temp = temp.siguiente;
            }
            
            // Intercambiar valores
            if (minNodo != actual) {
                int valorTemp = actual.getValor();
                actual.setValor(minNodo.getValor());
                minNodo.setValor(valorTemp);
            }
            
            actual = actual.siguiente;
        }
    }

    @Override
    public void OrdenarMergesort() {
        cabeza = mergeSort(cabeza);
    }
    
     private Nodo mergeSort(Nodo inicio){
        if (inicio == null || inicio.getSiguiente() == null) {
            return inicio;
        }

        Nodo medio = obtenerMitad(inicio);
        Nodo segundaMitad = medio.getSiguiente();
        medio.setSiguiente(null);

        Nodo izquierda = mergeSort(inicio);
        Nodo derecha = mergeSort(segundaMitad);

        return fusionar(izquierda, derecha);
    }
     
    private Nodo obtenerMitad(Nodo inicio){
        Nodo lento = inicio;
        Nodo rapido = inicio.getSiguiente();

        while (rapido != null && rapido.getSiguiente() != null) {
            lento = lento.getSiguiente();
            rapido = rapido.getSiguiente().getSiguiente();
        }

        return lento;
    }

    private Nodo fusionar(Nodo l1, Nodo l2){
        Nodo dummy = new Nodo(0);
        Nodo actual = dummy;

        while (l1 != null && l2 != null) {
            if (l1.getValor() <= l2.getValor()) {
                actual.setSiguiente(l1);
                l1 = l1.getSiguiente();
            } else {
                actual.setSiguiente(l2);
                l2 = l2.getSiguiente();
            }
            actual = actual.getSiguiente();
        }

        if (l1 != null) actual.setSiguiente(l1);
        if (l2 != null) actual.setSiguiente(l2);

        return dummy.getSiguiente();
    }    
    
    @Override
    public void OrdenarQuicksort() {
        cabeza = quickSort(cabeza, obtenerUltimo(cabeza));
    }
    
    private Nodo obtenerUltimo(Nodo nodo) {
        if (nodo == null) return null;
        while (nodo.siguiente != null) {
            nodo = nodo.siguiente;
        }
        return nodo;
    }
    
    private Nodo quickSort(Nodo inicio, Nodo fin) {
        if (inicio == null || inicio == fin) {
            return inicio;
        }
        
        // Particionar y obtener el pivote
        Nodo[] resultado = particionar(inicio, fin);
        Nodo pivote = resultado[0];
        Nodo nuevaInicio = resultado[1];
        
        // Si el pivote es el primer elemento, no hay elementos antes de él
        if (nuevaInicio != pivote) {
            // Encontrar el nodo anterior al pivote
            Nodo temp = nuevaInicio;
            while (temp.siguiente != pivote) {
                temp = temp.siguiente;
            }
            temp.siguiente = null;
            
            // Ordenar recursivamente la parte antes del pivote
            nuevaInicio = quickSort(nuevaInicio, temp);
            
            // Reconectar al pivote
            temp = obtenerUltimo(nuevaInicio);
            temp.siguiente = pivote;
        }
        
        // Ordenar recursivamente la parte después del pivote
        pivote.siguiente = quickSort(pivote.siguiente, fin);
        
        return nuevaInicio;
    }
    
    private Nodo[] particionar(Nodo inicio, Nodo fin) {
        Nodo pivote = fin;
        Nodo anterior = null;
        Nodo actual = inicio;
        Nodo cola = pivote;
        
        // Durante la partición, movemos elementos mayores al pivote al final
        while (actual != pivote) {
            if (actual.getValor() < pivote.getValor()) {
                if (anterior == null) {
                    inicio = actual;
                }
                anterior = actual;
                actual = actual.siguiente;
            } else {
                // Mover actual al final
                if (anterior != null) {
                    anterior.siguiente = actual.siguiente;
                }
                Nodo temp = actual.siguiente;
                actual.siguiente = null;
                cola.siguiente = actual;
                cola = actual;
                actual = temp;
            }
        }
        
        // Si el pivote quedó al inicio
        if (anterior == null) {
            inicio = pivote;
        } else {
            anterior.siguiente = pivote;
        }
        
        return new Nodo[]{pivote, inicio};
    }

    @Override
    public void OrdenarInsertionsort() {
        if (cabeza == null || cabeza.siguiente == null) return;
        
        Nodo ordenada = null; // Lista ordenada
        Nodo actual = cabeza;
        
        while (actual != null) {
            Nodo siguiente = actual.siguiente;
            
            // Insertar actual en la posición correcta de la lista ordenada
            if (ordenada == null || ordenada.getValor() >= actual.getValor()) {
                // Insertar al inicio
                actual.siguiente = ordenada;
                ordenada = actual;
            } else {
                // Buscar la posición correcta
                Nodo temp = ordenada;
                while (temp.siguiente != null && temp.siguiente.getValor() < actual.getValor()) {
                    temp = temp.siguiente;
                }
                actual.siguiente = temp.siguiente;
                temp.siguiente = actual;
            }
            
            actual = siguiente;
        }
        
        cabeza = ordenada;
    }
    
    
}
