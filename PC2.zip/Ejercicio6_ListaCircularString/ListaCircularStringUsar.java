package Ejercicio6_ListaCircularString;

public class ListaCircularStringUsar implements ListaCircularString {
    private NodoCircularString cabeza;
    private NodoCircularString actual;
    private int tamanio;

    public ListaCircularStringUsar() {
        this.cabeza = null;
        this.actual = null;
        this.tamanio = 0;
    }

    @Override
    public void agregar(String valor) {
        NodoCircularString nuevo = new NodoCircularString(valor);
        if (cabeza == null) {
            cabeza = nuevo;
            nuevo.setSiguiente(cabeza);
            actual = cabeza;
        } else {
            NodoCircularString temp = cabeza;
            while (temp.getSiguiente() != cabeza) temp = temp.getSiguiente();
            temp.setSiguiente(nuevo);
            nuevo.setSiguiente(cabeza);
        }
        tamanio++;
    }

    @Override
    public void agregarInicio(String valor) {
        NodoCircularString nuevo = new NodoCircularString(valor);
        if (cabeza == null) {
            cabeza = nuevo;
            nuevo.setSiguiente(cabeza);
            actual = cabeza;
        } else {
            NodoCircularString temp = cabeza;
            while (temp.getSiguiente() != cabeza) temp = temp.getSiguiente();
            nuevo.setSiguiente(cabeza);
            temp.setSiguiente(nuevo);
            cabeza = nuevo;
            actual = cabeza;
        }
        tamanio++;
    }

    @Override
    public boolean eliminar(String valor) {
        if (cabeza == null) return false;
        if (cabeza.getSiguiente() == cabeza && cabeza.getValor().equals(valor)) {
            cabeza = null;
            actual = null;
            tamanio--;
            return true;
        }
        if (cabeza.getValor().equals(valor)) {
            NodoCircularString temp = cabeza;
            while (temp.getSiguiente() != cabeza) temp = temp.getSiguiente();
            temp.setSiguiente(cabeza.getSiguiente());
            cabeza = cabeza.getSiguiente();
            actual = cabeza;
            tamanio--;
            return true;
        }
        NodoCircularString temp = cabeza;
        do {
            if (temp.getSiguiente().getValor().equals(valor)) {
                temp.setSiguiente(temp.getSiguiente().getSiguiente());
                if (actual.getValor().equals(valor)) actual = temp.getSiguiente();
                tamanio--;
                return true;
            }
            temp = temp.getSiguiente();
        } while (temp != cabeza);
        return false;
    }

    @Override
    public boolean contiene(String valor) {
        if (cabeza == null) return false;
        NodoCircularString temp = cabeza;
        do {
            if (temp.getValor().equals(valor)) return true;
            temp = temp.getSiguiente();
        } while (temp != cabeza);
        return false;
    }

    @Override
    public void imprimir() {
        if (cabeza == null) {
            System.out.println("Lista vacía");
            return;
        }
        NodoCircularString temp = cabeza;
        System.out.print("Circular String: ");
        do {
            System.out.print("\"" + temp.getValor() + "\" -> ");
            temp = temp.getSiguiente();
        } while (temp != cabeza);
        System.out.println("(cabeza)");
    }

    @Override
    public void imprimirCompleta() {
        if (cabeza == null) {
            System.out.println("Lista vacía");
            return;
        }
        NodoCircularString temp = cabeza;
        System.out.println("Vuelta completa:");
        do {
            System.out.println("  - \"" + temp.getValor() + "\"");
            temp = temp.getSiguiente();
        } while (temp != cabeza);
    }

    @Override
    public void avanzar() {
        if (actual != null) actual = actual.getSiguiente();
    }

    @Override
    public String obtenerActual() {
        if (actual != null) return actual.getValor();
        throw new IllegalStateException("Lista vacía");
    }

    @Override
    public boolean estaVacia() {
        return cabeza == null;
    }

    @Override
    public int tamanio() {
        return tamanio;
    }

    @Override
    public void OrdenarBubbleSort() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        boolean huboIntercambio;
        do {
            huboIntercambio = false;
            NodoCircularString temp = cabeza;
            do {
                NodoCircularString siguiente = temp.getSiguiente();
                if (temp.getValor().compareTo(siguiente.getValor()) > 0) {
                    String valorTemp = temp.getValor();
                    temp.setValor(siguiente.getValor());
                    siguiente.setValor(valorTemp);
                    huboIntercambio = true;
                }
                temp = temp.getSiguiente();
            } while (temp.getSiguiente() != cabeza);
        } while (huboIntercambio);
    }

    @Override
    public void OrdenarSelectionSort() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        NodoCircularString i = cabeza;
        do {
            NodoCircularString minNodo = i;
            NodoCircularString j = i.getSiguiente();
            while (j != cabeza) {
                if (j.getValor().compareTo(minNodo.getValor()) < 0) minNodo = j;
                j = j.getSiguiente();
            }
            if (minNodo != i) {
                String temp = i.getValor();
                i.setValor(minNodo.getValor());
                minNodo.setValor(temp);
            }
            i = i.getSiguiente();
        } while (i.getSiguiente() != cabeza);
    }

    @Override
    public void OrdenarInsertionSort() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        romperYOrdenar(true, false);
    }

    @Override
    public void OrdenarMergeSort() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        romperYOrdenar(false, true);
    }

    @Override
    public void OrdenarQuickSort() {
        if (cabeza == null || cabeza.getSiguiente() == cabeza) return;
        romperYOrdenar(false, false);
    }

    private void romperYOrdenar(boolean insertion, boolean merge) {
        NodoCircularString ultimo = cabeza;
        while (ultimo.getSiguiente() != cabeza) ultimo = ultimo.getSiguiente();
        ultimo.setSiguiente(null);
        
        if (insertion) cabeza = insertionSort(cabeza);
        else if (merge) cabeza = mergeSort(cabeza);
        else cabeza = quickSort(cabeza, obtenerUltimo(cabeza));
        
        ultimo = cabeza;
        while (ultimo.getSiguiente() != null) ultimo = ultimo.getSiguiente();
        ultimo.setSiguiente(cabeza);
        actual = cabeza;
    }

    private NodoCircularString insertionSort(NodoCircularString inicio) {
        NodoCircularString ordenada = null;
        NodoCircularString current = inicio;
        while (current != null) {
            NodoCircularString siguiente = current.getSiguiente();
            if (ordenada == null || ordenada.getValor().compareTo(current.getValor()) >= 0) {
                current.setSiguiente(ordenada);
                ordenada = current;
            } else {
                NodoCircularString temp = ordenada;
                while (temp.getSiguiente() != null && temp.getSiguiente().getValor().compareTo(current.getValor()) < 0) {
                    temp = temp.getSiguiente();
                }
                current.setSiguiente(temp.getSiguiente());
                temp.setSiguiente(current);
            }
            current = siguiente;
        }
        return ordenada;
    }

    private NodoCircularString mergeSort(NodoCircularString inicio) {
        if (inicio == null || inicio.getSiguiente() == null) return inicio;
        NodoCircularString medio = obtenerMitad(inicio);
        NodoCircularString segundaMitad = medio.getSiguiente();
        medio.setSiguiente(null);
        return fusionar(mergeSort(inicio), mergeSort(segundaMitad));
    }

    private NodoCircularString obtenerMitad(NodoCircularString inicio) {
        if (inicio == null) return null;
        NodoCircularString lento = inicio, rapido = inicio.getSiguiente();
        while (rapido != null && rapido.getSiguiente() != null) {
            lento = lento.getSiguiente();
            rapido = rapido.getSiguiente().getSiguiente();
        }
        return lento;
    }

    private NodoCircularString fusionar(NodoCircularString l1, NodoCircularString l2) {
        NodoCircularString dummy = new NodoCircularString("");
        NodoCircularString current = dummy;
        while (l1 != null && l2 != null) {
            if (l1.getValor().compareTo(l2.getValor()) <= 0) {
                current.setSiguiente(l1);
                l1 = l1.getSiguiente();
            } else {
                current.setSiguiente(l2);
                l2 = l2.getSiguiente();
            }
            current = current.getSiguiente();
        }
        if (l1 != null) current.setSiguiente(l1);
        if (l2 != null) current.setSiguiente(l2);
        return dummy.getSiguiente();
    }

    private NodoCircularString quickSort(NodoCircularString inicio, NodoCircularString fin) {
        if (inicio == null || inicio == fin) return inicio;
        NodoCircularString[] resultado = particionar(inicio, fin);
        NodoCircularString pivote = resultado[0];
        NodoCircularString nuevoInicio = resultado[1];
        if (nuevoInicio != pivote) {
            NodoCircularString temp = nuevoInicio;
            while (temp.getSiguiente() != pivote) temp = temp.getSiguiente();
            temp.setSiguiente(null);
            nuevoInicio = quickSort(nuevoInicio, temp);
            temp = obtenerUltimo(nuevoInicio);
            temp.setSiguiente(pivote);
        }
        pivote.setSiguiente(quickSort(pivote.getSiguiente(), fin));
        return nuevoInicio;
    }

    private NodoCircularString[] particionar(NodoCircularString inicio, NodoCircularString fin) {
        NodoCircularString pivote = fin, anterior = null, current = inicio, cola = pivote;
        while (current != pivote) {
            if (current.getValor().compareTo(pivote.getValor()) < 0) {
                if (anterior == null) inicio = current;
                anterior = current;
                current = current.getSiguiente();
            } else {
                if (anterior != null) anterior.setSiguiente(current.getSiguiente());
                NodoCircularString temp = current.getSiguiente();
                current.setSiguiente(null);
                cola.setSiguiente(current);
                cola = current;
                current = temp;
            }
        }
        if (anterior == null) inicio = pivote;
        else anterior.setSiguiente(pivote);
        return new NodoCircularString[]{pivote, inicio};
    }

    private NodoCircularString obtenerUltimo(NodoCircularString nodo) {
        if (nodo == null) return null;
        while (nodo.getSiguiente() != null) nodo = nodo.getSiguiente();
        return nodo;
    }
}
