package facade;

import enums.CondicionContrato;
import enums.Especialidad;

public class CalculadoraSalarial {
    
    private static final double DESCUENTO_AFP = 0.15;
    private static final double DESCUENTO_SNP = 0.08;
    
    public double calcularSueldoBase(CondicionContrato condicion, int supervisionObras, int supervisionVias) {
        double tarifaObras = (condicion == CondicionContrato.ESTABLE) ? 4000 : 2000;
        double tarifaVias = (condicion == CondicionContrato.ESTABLE) ? 6000 : 4500;
        
        return (supervisionObras * tarifaObras) + (supervisionVias * tarifaVias);
    }
    
    public double calcularBonificacion(double sueldoBase, Especialidad especialidad) {
        double porcentaje = 0;
        
        switch (especialidad) {
            case ESTRUCTURAS:
                porcentaje = 0.16;
                break;
            case RECURSOS_HIDRICOS:
                porcentaje = 0.18;
                break;
            case INGENIERIA_VIAL:
                porcentaje = 0.22;
                break;
        }
        
        return sueldoBase * porcentaje;
    }
    
    public double calcularDescuentoAFP(double sueldoBase) {
        return sueldoBase * DESCUENTO_AFP;
    }
    
    public double calcularDescuentoSNP(double sueldoBase) {
        return sueldoBase * DESCUENTO_SNP;
    }
    
    public double calcularMovilidad(int numeroObras) {
        return (numeroObras <= 17) ? 300 : 600;
    }
    
    public double calcularSueldoNeto(CondicionContrato condicion, int supervisionObras, 
                                     int supervisionVias, Especialidad especialidad, 
                                     int numeroObras, boolean usarAFP) {
        double sueldoBase = calcularSueldoBase(condicion, supervisionObras, supervisionVias);
        double bonificacion = calcularBonificacion(sueldoBase, especialidad);
        double descuento = usarAFP ? calcularDescuentoAFP(sueldoBase) : calcularDescuentoSNP(sueldoBase);
        double movilidad = calcularMovilidad(numeroObras);
        
        return sueldoBase + bonificacion - descuento + movilidad;
    }
}
