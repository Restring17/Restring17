package Ejercicio2;

/**
 *
 * @author User
 */
public class ListaEnlazadaPokemonUsar implements ListaEnlazadaPokemon {
    private NodoPokemon cabeza;

    public ListaEnlazadaPokemonUsar() {
        cabeza = null;
    }

    @Override
    public void agregarInicio(Pokemon pokemon) {
        NodoPokemon nuevo = new NodoPokemon(pokemon);
        nuevo.siguiente = cabeza;
        cabeza = nuevo;
    }

    @Override
    public void agregarFinal(Pokemon pokemon) {
        NodoPokemon nuevo = new NodoPokemon(pokemon);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            NodoPokemon actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevo;
        }
    }

    @Override
    public boolean eliminar(String nombre) {
        if (cabeza == null) return false;
        if (cabeza.pokemon.getNombre().equals(nombre)) {
            cabeza = cabeza.siguiente;
            return true;
        }
        NodoPokemon actual = cabeza;
        while (actual.siguiente != null && !actual.siguiente.pokemon.getNombre().equals(nombre)) {
            actual = actual.siguiente;
        }
        if (actual.siguiente == null) return false;
        actual.siguiente = actual.siguiente.siguiente;
        return true;
    }

    @Override
    public boolean contiene(String nombre) {
        NodoPokemon actual = cabeza;
        while (actual != null) {
            if (actual.pokemon.getNombre().equals(nombre)) return true;
            actual = actual.siguiente;
        }
        return false;
    }

    @Override
    public boolean contieneOrdenado(String nombre) {
        NodoPokemon actual = cabeza;
        while (actual != null) {
            if (actual.pokemon.getNombre().equals(nombre)) {
                return true;
            } else if (actual.pokemon.getNombre().compareTo(nombre) > 0) {
                return false;
            }
            actual = actual.siguiente;
        }
        return false;
    }

    @Override
    public void imprimir() {
        NodoPokemon actual = cabeza;
        while (actual != null) {
            System.out.print("- " + actual.pokemon);
            actual = actual.siguiente;
        }
        System.out.println(" - null");
    }

    // ==================== ORDENAMIENTO POR PODER ====================
    
    @Override
    public void OrdenarBubbleSortPorPoder() {
        if (cabeza == null || cabeza.siguiente == null) return;
        boolean huboIntercambio;
        do {
            NodoPokemon actual = cabeza;
            NodoPokemon siguiente = cabeza.siguiente;
            huboIntercambio = false;
            while (siguiente != null) {
                if (actual.getPokemon().getPoder() > siguiente.getPokemon().getPoder()) {
                    Pokemon temp = actual.getPokemon();
                    actual.setPokemon(siguiente.getPokemon());
                    siguiente.setPokemon(temp);
                    huboIntercambio = true;
                }
                actual = siguiente;
                siguiente = siguiente.getSiguiente();
            }
        } while (huboIntercambio);
    }

    @Override
    public void OrdenarSelectionSortPorPoder() {
        if (cabeza == null || cabeza.siguiente == null) return;
        
        NodoPokemon actual = cabeza;
        
        while (actual != null) {
            NodoPokemon minNodo = actual;
            NodoPokemon temp = actual.siguiente;
            
            while (temp != null) {
                if (temp.getPokemon().getPoder() < minNodo.getPokemon().getPoder()) {
                    minNodo = temp;
                }
                temp = temp.siguiente;
            }
            
            if (minNodo != actual) {
                Pokemon pokemonTemp = actual.getPokemon();
                actual.setPokemon(minNodo.getPokemon());
                minNodo.setPokemon(pokemonTemp);
            }
            
            actual = actual.siguiente;
        }
    }

    @Override
    public void OrdenarMergeSortPorPoder() {
        cabeza = mergeSortPoder(cabeza);
    }
    
    private NodoPokemon mergeSortPoder(NodoPokemon inicio) {
        if (inicio == null || inicio.getSiguiente() == null) {
            return inicio;
        }

        NodoPokemon medio = obtenerMitad(inicio);
        NodoPokemon segundaMitad = medio.getSiguiente();
        medio.setSiguiente(null);

        NodoPokemon izquierda = mergeSortPoder(inicio);
        NodoPokemon derecha = mergeSortPoder(segundaMitad);

        return fusionarPoder(izquierda, derecha);
    }

    private NodoPokemon fusionarPoder(NodoPokemon l1, NodoPokemon l2) {
        NodoPokemon dummy = new NodoPokemon(new Pokemon("", "", 0));
        NodoPokemon actual = dummy;

        while (l1 != null && l2 != null) {
            if (l1.getPokemon().getPoder() <= l2.getPokemon().getPoder()) {
                actual.setSiguiente(l1);
                l1 = l1.getSiguiente();
            } else {
                actual.setSiguiente(l2);
                l2 = l2.getSiguiente();
            }
            actual = actual.getSiguiente();
        }

        if (l1 != null) actual.setSiguiente(l1);
        if (l2 != null) actual.setSiguiente(l2);

        return dummy.getSiguiente();
    }

    @Override
    public void OrdenarQuickSortPorPoder() {
        cabeza = quickSortPoder(cabeza, obtenerUltimo(cabeza));
    }
    
    private NodoPokemon quickSortPoder(NodoPokemon inicio, NodoPokemon fin) {
        if (inicio == null || inicio == fin) {
            return inicio;
        }
        
        NodoPokemon[] resultado = particionarPoder(inicio, fin);
        NodoPokemon pivote = resultado[0];
        NodoPokemon nuevaInicio = resultado[1];
        
        if (nuevaInicio != pivote) {
            NodoPokemon temp = nuevaInicio;
            while (temp.siguiente != pivote) {
                temp = temp.siguiente;
            }
            temp.siguiente = null;
            
            nuevaInicio = quickSortPoder(nuevaInicio, temp);
            
            temp = obtenerUltimo(nuevaInicio);
            temp.siguiente = pivote;
        }
        
        pivote.siguiente = quickSortPoder(pivote.siguiente, fin);
        
        return nuevaInicio;
    }
    
    private NodoPokemon[] particionarPoder(NodoPokemon inicio, NodoPokemon fin) {
        NodoPokemon pivote = fin;
        NodoPokemon anterior = null;
        NodoPokemon actual = inicio;
        NodoPokemon cola = pivote;
        
        while (actual != pivote) {
            if (actual.getPokemon().getPoder() < pivote.getPokemon().getPoder()) {
                if (anterior == null) {
                    inicio = actual;
                }
                anterior = actual;
                actual = actual.siguiente;
            } else {
                if (anterior != null) {
                    anterior.siguiente = actual.siguiente;
                }
                NodoPokemon temp = actual.siguiente;
                actual.siguiente = null;
                cola.siguiente = actual;
                cola = actual;
                actual = temp;
            }
        }
        
        if (anterior == null) {
            inicio = pivote;
        } else {
            anterior.siguiente = pivote;
        }
        
        return new NodoPokemon[]{pivote, inicio};
    }

    @Override
    public void OrdenarInsertionSortPorPoder() {
        if (cabeza == null || cabeza.siguiente == null) return;
        
        NodoPokemon ordenada = null;
        NodoPokemon actual = cabeza;
        
        while (actual != null) {
            NodoPokemon siguiente = actual.siguiente;
            
            if (ordenada == null || ordenada.getPokemon().getPoder() >= actual.getPokemon().getPoder()) {
                actual.siguiente = ordenada;
                ordenada = actual;
            } else {
                NodoPokemon temp = ordenada;
                while (temp.siguiente != null && temp.siguiente.getPokemon().getPoder() < actual.getPokemon().getPoder()) {
                    temp = temp.siguiente;
                }
                actual.siguiente = temp.siguiente;
                temp.siguiente = actual;
            }
            
            actual = siguiente;
        }
        
        cabeza = ordenada;
    }

    // ==================== ORDENAMIENTO POR NOMBRE ====================
    
    @Override
    public void OrdenarBubbleSortPorNombre() {
        if (cabeza == null || cabeza.siguiente == null) return;
        boolean huboIntercambio;
        do {
            NodoPokemon actual = cabeza;
            NodoPokemon siguiente = cabeza.siguiente;
            huboIntercambio = false;
            while (siguiente != null) {
                if (actual.getPokemon().getNombre().compareTo(siguiente.getPokemon().getNombre()) > 0) {
                    Pokemon temp = actual.getPokemon();
                    actual.setPokemon(siguiente.getPokemon());
                    siguiente.setPokemon(temp);
                    huboIntercambio = true;
                }
                actual = siguiente;
                siguiente = siguiente.getSiguiente();
            }
        } while (huboIntercambio);
    }

    @Override
    public void OrdenarSelectionSortPorNombre() {
        if (cabeza == null || cabeza.siguiente == null) return;
        
        NodoPokemon actual = cabeza;
        
        while (actual != null) {
            NodoPokemon minNodo = actual;
            NodoPokemon temp = actual.siguiente;
            
            while (temp != null) {
                if (temp.getPokemon().getNombre().compareTo(minNodo.getPokemon().getNombre()) < 0) {
                    minNodo = temp;
                }
                temp = temp.siguiente;
            }
            
            if (minNodo != actual) {
                Pokemon pokemonTemp = actual.getPokemon();
                actual.setPokemon(minNodo.getPokemon());
                minNodo.setPokemon(pokemonTemp);
            }
            
            actual = actual.siguiente;
        }
    }

    @Override
    public void OrdenarMergeSortPorNombre() {
        cabeza = mergeSortNombre(cabeza);
    }
    
    private NodoPokemon mergeSortNombre(NodoPokemon inicio) {
        if (inicio == null || inicio.getSiguiente() == null) {
            return inicio;
        }

        NodoPokemon medio = obtenerMitad(inicio);
        NodoPokemon segundaMitad = medio.getSiguiente();
        medio.setSiguiente(null);

        NodoPokemon izquierda = mergeSortNombre(inicio);
        NodoPokemon derecha = mergeSortNombre(segundaMitad);

        return fusionarNombre(izquierda, derecha);
    }

    private NodoPokemon fusionarNombre(NodoPokemon l1, NodoPokemon l2) {
        NodoPokemon dummy = new NodoPokemon(new Pokemon("", "", 0));
        NodoPokemon actual = dummy;

        while (l1 != null && l2 != null) {
            if (l1.getPokemon().getNombre().compareTo(l2.getPokemon().getNombre()) <= 0) {
                actual.setSiguiente(l1);
                l1 = l1.getSiguiente();
            } else {
                actual.setSiguiente(l2);
                l2 = l2.getSiguiente();
            }
            actual = actual.getSiguiente();
        }

        if (l1 != null) actual.setSiguiente(l1);
        if (l2 != null) actual.setSiguiente(l2);

        return dummy.getSiguiente();
    }

    @Override
    public void OrdenarQuickSortPorNombre() {
        cabeza = quickSortNombre(cabeza, obtenerUltimo(cabeza));
    }
    
    private NodoPokemon quickSortNombre(NodoPokemon inicio, NodoPokemon fin) {
        if (inicio == null || inicio == fin) {
            return inicio;
        }
        
        NodoPokemon[] resultado = particionarNombre(inicio, fin);
        NodoPokemon pivote = resultado[0];
        NodoPokemon nuevaInicio = resultado[1];
        
        if (nuevaInicio != pivote) {
            NodoPokemon temp = nuevaInicio;
            while (temp.siguiente != pivote) {
                temp = temp.siguiente;
            }
            temp.siguiente = null;
            
            nuevaInicio = quickSortNombre(nuevaInicio, temp);
            
            temp = obtenerUltimo(nuevaInicio);
            temp.siguiente = pivote;
        }
        
        pivote.siguiente = quickSortNombre(pivote.siguiente, fin);
        
        return nuevaInicio;
    }
    
    private NodoPokemon[] particionarNombre(NodoPokemon inicio, NodoPokemon fin) {
        NodoPokemon pivote = fin;
        NodoPokemon anterior = null;
        NodoPokemon actual = inicio;
        NodoPokemon cola = pivote;
        
        while (actual != pivote) {
            if (actual.getPokemon().getNombre().compareTo(pivote.getPokemon().getNombre()) < 0) {
                if (anterior == null) {
                    inicio = actual;
                }
                anterior = actual;
                actual = actual.siguiente;
            } else {
                if (anterior != null) {
                    anterior.siguiente = actual.siguiente;
                }
                NodoPokemon temp = actual.siguiente;
                actual.siguiente = null;
                cola.siguiente = actual;
                cola = actual;
                actual = temp;
            }
        }
        
        if (anterior == null) {
            inicio = pivote;
        } else {
            anterior.siguiente = pivote;
        }
        
        return new NodoPokemon[]{pivote, inicio};
    }

    @Override
    public void OrdenarInsertionSortPorNombre() {
        if (cabeza == null || cabeza.siguiente == null) return;
        
        NodoPokemon ordenada = null;
        NodoPokemon actual = cabeza;
        
        while (actual != null) {
            NodoPokemon siguiente = actual.siguiente;
            
            if (ordenada == null || ordenada.getPokemon().getNombre().compareTo(actual.getPokemon().getNombre()) >= 0) {
                actual.siguiente = ordenada;
                ordenada = actual;
            } else {
                NodoPokemon temp = ordenada;
                while (temp.siguiente != null && temp.siguiente.getPokemon().getNombre().compareTo(actual.getPokemon().getNombre()) < 0) {
                    temp = temp.siguiente;
                }
                actual.siguiente = temp.siguiente;
                temp.siguiente = actual;
            }
            
            actual = siguiente;
        }
        
        cabeza = ordenada;
    }

    // ==================== MÉTODOS AUXILIARES ====================
    
    private NodoPokemon obtenerMitad(NodoPokemon inicio) {
        NodoPokemon lento = inicio;
        NodoPokemon rapido = inicio.getSiguiente();

        while (rapido != null && rapido.getSiguiente() != null) {
            lento = lento.getSiguiente();
            rapido = rapido.getSiguiente().getSiguiente();
        }

        return lento;
    }
    
    private NodoPokemon obtenerUltimo(NodoPokemon nodo) {
        if (nodo == null) return null;
        while (nodo.siguiente != null) {
            nodo = nodo.siguiente;
        }
        return nodo;
    }
}
