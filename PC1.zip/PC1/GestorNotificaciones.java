package PC1;

/**
 *
 * @author User
 */
public class GestorNotificaciones {
    
    // SRP - Solo se encarga de procesar el envío
    public void procesarEnvio(CanalNotificacion canal, Mensaje mensaje) {
        System.out.println("Procesando envío de " + mensaje.getTipo());
        canal.enviar(mensaje);
        System.out.println("Envío procesado exitosamente");
    }
}